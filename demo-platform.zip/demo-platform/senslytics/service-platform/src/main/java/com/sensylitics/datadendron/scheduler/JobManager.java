package com.sensylitics.datadendron.scheduler;

import java.util.Date;
import java.util.logging.Logger;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;
import com.senslytics.datadendron.adapter.JobProcessor;
import com.senslytics.datadendron.adapter.PIDataManager;
import com.senslytics.datadendron.adapter.PiROraManager;
import com.senslytics.datadendron.adapter.RManager;
//import sensylitics.suit.datadendron.adapter.*;
import com.senslytics.datadendron.utils.JobUtils;
import com.senslytics.datadendron.utils.TriggerUtils;

public class JobManager implements JobProcessor {

    static Logger log = Logger.getLogger(JobManager.class.getName());

    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("In JobManager execute()");
        try {
            SchedulerFactory jmFactory = new StdSchedulerFactory();
            Scheduler jmScheduler = jmFactory.getScheduler();
            jmScheduler.start();

            Date startTime = new Date(System.currentTimeMillis() + 1000);
            String sRandom = Double.toString(Math.random());

            JobUtils jobPiDataCollector = new JobUtils(PIDataManager.class, "PI Data Collection Job" + sRandom);
            TriggerUtils triggerPiDataCollector = new TriggerUtils(startTime, 0, 60000 * 1 * 30, "PI Data Collection Trigger" + sRandom);

            JobUtils jobR = new JobUtils(RManager.class, "R Job" + sRandom);
            TriggerUtils triggerR = new TriggerUtils(startTime, 0, 60000 * 1 * 30, "R Trigger" + sRandom);

            JobUtils jobPiROra = new JobUtils(PiROraManager.class, "PiROra Job" + sRandom);
            TriggerUtils triggerPiROra = new TriggerUtils(startTime, 15, 60000 * 1 * 30, "PiROra Trigger" + sRandom);

            //jmScheduler.scheduleJob(jobPiDataCollector,triggerPiDataCollector); 
            //jmScheduler.scheduleJob(jobR,triggerR); //Failure Data
            jmScheduler.scheduleJob(jobPiROra, triggerPiROra); //Current Data
        } catch (Exception e) {
            log.info("Exception at JobManager" + e.getMessage());
        }

    }

}
