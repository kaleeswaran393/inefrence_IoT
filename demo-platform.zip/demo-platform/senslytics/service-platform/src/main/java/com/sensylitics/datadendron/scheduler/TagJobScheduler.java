package com.sensylitics.datadendron.scheduler;

import java.util.Date;
import java.util.logging.Logger;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import com.senslytics.datadendron.utils.JobUtils;
import com.senslytics.datadendron.utils.SchedularUtils;
import com.senslytics.datadendron.utils.TriggerUtils;

public class TagJobScheduler {
	static Logger log=Logger.getLogger(TagJobScheduler.class.getName());
	SchedularUtils schfactory=new SchedularUtils(); 
	
	public static void main(String[] args) throws SchedulerException {
		log.info("Schedular Start");
		SchedulerFactory factory=new StdSchedulerFactory();
		Scheduler scheduler =factory.getScheduler();
		Date startTime=new Date(System.currentTimeMillis() + 1000);
				
		JobUtils jobManager=new JobUtils(TagJobManager.class,"Job Manager Job");
		TriggerUtils triggerJobManager=new TriggerUtils(startTime,0,60000*1*30,"Job Manager Trigger");
				
		scheduler.start();
		scheduler.scheduleJob(jobManager,triggerJobManager);
	    log.info("Schedular End");
	}

}
