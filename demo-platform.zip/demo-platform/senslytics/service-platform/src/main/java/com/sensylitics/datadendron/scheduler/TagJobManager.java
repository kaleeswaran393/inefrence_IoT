package com.sensylitics.datadendron.scheduler;

import java.util.Date;
import org.apache.log4j.Logger;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import com.senslytics.datadendron.utils.JobUtils;
import com.senslytics.datadendron.utils.TriggerUtils;
import com.senslytics.datadendron.adapter.JobProcessor;

public class TagJobManager implements JobProcessor {

	static Logger log=Logger.getLogger(TagJobManager.class.getName());

	
	public void execute(JobExecutionContext context)
			throws JobExecutionException {
		log.info("In JobManager execute()");
		try
		{	
			SchedulerFactory jmFactory=new StdSchedulerFactory();
			Scheduler jmScheduler =jmFactory.getScheduler();
			jmScheduler.start();

			Date startTime=new Date(System.currentTimeMillis() + 1000);
			String sRandom=Double.toString(Math.random());
		
			JobUtils jobPi=new JobUtils(PIJob.class,"Pi Job"+sRandom);
			TriggerUtils triggerPi=new TriggerUtils(startTime, 0,60000*1*2,"Pi Trigger"+sRandom);		
			jmScheduler.scheduleJob(jobPi,triggerPi); //Current Data
		}
		catch(Exception e)
		{
			log.error("Exception at JobManager"+e.getMessage());
		}
		
	}

}
