package com.sensylitics.datadendron.scheduler;


import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.senslytics.datadendron.scheduler.TagComponentThread;
import com.senslytics.datadendron.adapter.RDBMSDataProvider;
import com.senslytics.datadendron.utils.PropertiesUtils;

public class PIJob implements Job {

	static Logger log=Logger.getLogger(PIJob.class.getName());
	RDBMSDataProvider dataProvider;
	List<String> tagList;
	ExecutorService executor;
	PropertiesConfiguration prop;

	public void execute(JobExecutionContext context)
			throws JobExecutionException {
		try{
			prop= new PropertiesUtils().getProperties();
				
			dataProvider=new RDBMSDataProvider();
			tagList=dataProvider.getTagList();
			executor=Executors.newFixedThreadPool(tagList.size());
			
			for(String tag : tagList){
				
				Runnable task=new TagComponentThread(tag) ;
				executor.execute(task);	
			}
			shutDownProcess(prop, executor);
			
		}catch(Exception e){
			log.error("Exception at PiJob execute()"+e.getMessage());
		}
		
	}
	private void shutDownProcess(PropertiesConfiguration prop,
			ExecutorService executor) throws InterruptedException {
		executor.shutdown();
		if(!executor.awaitTermination(Integer.parseInt(prop.getString("waitTime")), TimeUnit.MINUTES))
		{
			log.info("Unable to finish thread execution in "+Integer.parseInt(prop.getString("waitTime"))+" minutes");
		}
	}

}
