package com.sensylitics.datadendron.rpackage;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;

import org.apache.commons.configuration.PropertiesConfiguration;

import com.senslytics.datadendron.oraadapter.ORAConnectionFactory;
import com.senslytics.datadendron.utils.PropertiesUtils;
import com.senslytics.datadendron.dao.RDataStore;

public class RAdapter extends RDataStore {

    static Logger log = Logger.getLogger(RAdapter.class.getName());

    @Override
    public ArrayList getData() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
//	public ArrayList insertData(String[] strTimeArray, double[] dobValArray ,String[] tag_name) {
    public ArrayList insertData(ArrayList alTagsTimeSeries, ArrayList alTagsValues, String[] tag_name, String sComponentName, Integer isDataFailure) {

        log.info("In RAdapter insertData()");
        ArrayList alRPredict = new ArrayList();
        ArrayList<Long> alTimestamps = new ArrayList<Long>();
        ORAConnectionFactory ocf = new ORAConnectionFactory();
        KVStore store = ocf.getKVStore();
        List<Row> myRows = null;
        TableAPI tableAPI = ocf.getTableAPI(store);
        Table tableChild = tableAPI.getTable("tag.sensor_reading");
        Table tableChild2 = tableAPI.getTable("pi_sensor.tag_detail");

        try {
            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            for (int m = 0, n = tag_name.length; m < n; m++) {
//	       		System.out.println("Current tag name"+tag_name[m]);
                String sTemp = "";
                String str = "";
                Long sTimeStampStart = 0L;
                Long sTimeStampEnd = 0L;
                String sDataPoints = "";
                int iRowSize = 0;
                if (isDataFailure == 1) {
                    PrimaryKey key = null;
                    FieldRange fh = null;
                    if (sComponentName.equals("BPESP1") || sComponentName.equals("BPGLC1")) {
                        /*fh = tableChild2.createFieldRange("tag_time");
                         key=tableChild2.createPrimaryKey();
                         fh.setStart(prop.getString(tag_name[m]+"_start"), true);
                         fh.setEnd(prop.getString(tag_name[m]+"_end"), true);
                         */
                        fh = tableChild.createFieldRange("tag_time");
                        key = tableChild.createPrimaryKey();
                        SimpleDateFormat sdfStartEnd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	       	//			Date dCurrStart=sdfStartEnd.parse(prop.getString(tag_name[m]+"_start"));
                        //			Date dCurrEnd=sdfStartEnd.parse(prop.getString(tag_name[m]+"_end"));

                        //			fh.setStart(new Timestamp(dCurrStart.getTime()).getTime(), true);
                        //       		fh.setEnd(new Timestamp(dCurrEnd.getTime()).getTime(), true);
                        fh.setStart(prop.getLong(tag_name[m] + "_start"), true);
                        fh.setEnd(prop.getLong(tag_name[m] + "_end"), true);
                    }
                    /*
                     if(sComponentName.equals("BPGLC1"))
                     {
                     fh = tableChild.createFieldRange("tag_time");
                     key=tableChild.createPrimaryKey();
                     SimpleDateFormat sdfStartEnd=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                     Date dCurrStart=sdfStartEnd.parse(prop.getString(tag_name[m]+"_start"));
                     Date dCurrEnd=sdfStartEnd.parse(prop.getString(tag_name[m]+"_end"));
	       	        
                     fh.setStart(new Timestamp(dCurrStart.getTime()).getTime(), true);
                     fh.setEnd(new Timestamp(dCurrEnd.getTime()).getTime(), true);
                     }*/
                    key.put("tag_name", tag_name[m]);
                    MultiRowOptions mro = fh.createMultiRowOptions();
                    myRows = tableAPI.multiGet(key, mro, null);
                    int i = 0;

                    System.out.println("Size of " + tag_name[m] + " Selection:" + myRows.size() + " Start:" + fh.getStart() + " End:" + fh.getEnd());

                    iRowSize = myRows.size();
                    alTimestamps.clear();
                    for (int p = 0, q = iRowSize; p < q; p++) {
                        Row theRow = myRows.get(p);
                        if (i < myRows.size() && !theRow.get("tag_value").asString().get().equalsIgnoreCase("null")) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//	       					Date dCurr=sdf.parse(theRow.get("tag_time").asString().get());

                            if (i == (myRows.size() - 1)) {
                                sTemp = sTemp + theRow.get("tag_value").asString().get();
//	       						sTimeStampEnd=new Timestamp(dCurr.getTime()).getTime();
                                sTimeStampEnd = theRow.get("tag_time").asLong().get();
                            } else {
                                sTemp = sTemp + theRow.get("tag_value").asString().get() + ",";
                            }
                            if (i == 0) {
                                //	sTimeStampStart=new Timestamp(dCurr.getTime()).getTime();
                                sTimeStampStart = theRow.get("tag_time").asLong().get();
                            }
                            //alTimestamps.add(new Timestamp(dCurr.getTime()).getTime());
                            alTimestamps.add(theRow.get("tag_time").asLong().get());
                            i++;
                        }
                    }
                    sTemp = sTemp + ",1";
                    //		System.out.println("Last Row"+sTemp);
                    str = "@relation Train-Experiment-2\n";
                    for (int x = 2, y = iRowSize + 2; x < y; x++) {
                        str = str + "@attribute V" + x + " numeric\n";
                    }

                    //	if(iRowSize==30)   {      str=str+  "@attribute V31 numeric\n";}
	       		/*	if(iRowSize==31)   {  
                     str=str+  "@attribute V31 numeric\n";
                     str=str+  "@attribute V32 numeric\n";
                     }           
                     */ str = str + "@attribute V1 {1,0}\n"
                                + "@data\n"
                                + sTemp + "\n";
                } else {
                    PrimaryKey key = tableChild.createPrimaryKey();
                    key.put("tag_name", tag_name[m]);
                    myRows = tableAPI.multiGet(key, null, null);
                    Long sStartTime = 0L;
                    Long sEndTime = 0L;
                    int i = 0;
                    iRowSize = prop.getInt("rsegmentsize");
                    alTimestamps.clear();
                    System.out.println("Size of Current Selection" + myRows.size());

                    for (int p = myRows.size() - iRowSize, q = myRows.size(); p < q; p++) {
                        Row theRow = myRows.get(p);
                        if (i < iRowSize && !theRow.get("tag_value").asString().get().equalsIgnoreCase("null")) {
                            if (i == iRowSize - 1) {
                                sTemp = sTemp + theRow.get("tag_value").asString().get();
                                sTimeStampEnd = theRow.get("tag_time").asLong().get();
                            } else {
                                sTemp = sTemp + theRow.get("tag_value").asString().get() + ",";
                            }
                        }
                        alTimestamps.add(theRow.get("tag_time").asLong().get());

                        if (i == 0) {
                            sStartTime = theRow.get("tag_time").asLong().get();
                            sTimeStampStart = theRow.get("tag_time").asLong().get();
                        }
                        if (i == iRowSize - 1) {
                            sEndTime = theRow.get("tag_time").asLong().get();
                        }
                        i++;
                    }

                    sTemp = sTemp + ",1";
                    str = "@relation Train-Experiment-2\n";
                    for (int x = 2, y = iRowSize + 2; x < y; x++) {
                        str = str + "@attribute V" + x + " numeric\n";
                    }
                    str = str + "@attribute V1 {1,0}\n"
                                + "@data\n"
                                + sTemp + "\n";
                }
                long[] lArray = new long[alTimestamps.size()];
                for (int x = 0, y = alTimestamps.size(); x < y; x++) {
                    lArray[x] = alTimestamps.get(x);
                }

                String sForInstance = str;
                Double dCurrPred = new papers.DMKD_2013_Updated().getPrediction(tag_name[m], isDataFailure, sForInstance);//System.out.println("Prediction for "+tag_name[m]+" is "+dCurrPred);	       		
                PredictionBean pb = new PredictionBean(dCurrPred.intValue(), tag_name[m], sTimeStampStart, sTimeStampEnd, lArray, iRowSize);
                System.out.println("Prediction for Tag:" + tag_name[m] + " is " + dCurrPred);
                alRPredict.add(pb);
            }
        } catch (Exception e) {
            log.info("Exception at RAdapter" + e.getMessage());
        }
        return alRPredict;
    }
}
