package com.sensylitics.datadendron.rpackage;

public class PredictionBean {

    private String tag_name;
    private int failure_predicted;
    private Long tw_start_date;
    private Long tw_end_date;
    private long[] time_frames;
    private int data_points;

    public PredictionBean(int prediction,
                String tag_name,
                Long start_time,
                Long end_time,
                long[] time_frames,
                int data_points
    ) {
        this.failure_predicted = prediction;
        this.tag_name = tag_name;
        this.tw_start_date = start_time;
        this.tw_end_date = end_time;
        this.time_frames = time_frames;
        this.data_points = data_points;
    }

    public String getTag_name() {
        return tag_name;
    }

    public void setTag_name(String tag_name) {
        this.tag_name = tag_name;
    }

    public int getFailure_predicted() {
        return failure_predicted;
    }

    public void setFailure_predicted(int failure_predicted) {
        this.failure_predicted = failure_predicted;
    }

    public Long getTw_start_date() {
        return tw_start_date;
    }

    public void setTw_start_date(Long tw_start_date) {
        this.tw_start_date = tw_start_date;
    }

    public Long getTw_end_date() {
        return tw_end_date;
    }

    public void setTw_end_date(Long tw_end_date) {
        this.tw_end_date = tw_end_date;
    }

    public long[] getTime_frames() {
        return time_frames;
    }

    public void setTime_frames(long[] time_frames) {
        this.time_frames = time_frames;
    }

    public int getData_points() {
        return data_points;
    }

    public void setData_points(int data_points) {
        this.data_points = data_points;
    }

}
