package com.sensylitics.datadendron.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.ConfigurationException;

import org.apache.commons.configuration.PropertiesConfiguration;

public class PropertiesUtils {

    static Logger log = Logger.getLogger(PropertiesUtils.class.getName());

    /*	public Properties getProperties()
     {
     log.info("In PropertyUtils getProperties()");
		
     Properties prop= new Properties();
     try
     {
     String sCsvPath=new File("").getAbsolutePath()+"/resources/config.properties"; 
     FileInputStream fs= new FileInputStream(sCsvPath);
     prop.load(fs);
     }
     catch(Exception e)
     {
     log.info("Exception at PropertyUtils getProperties()"+e.getMessage());
     }
     return prop;
     }
     */
    public PropertiesConfiguration getProperties() {
        log.setLevel(Level.INFO);
        PropertiesConfiguration config = null;
        final String PROPERTIES_FILE_NAME = new File("").getAbsolutePath() + "/src/main/resources/config.properties";
        try {
            config = new PropertiesConfiguration();
            config.load(PROPERTIES_FILE_NAME);
        } catch (Exception e) {
            log.info("Exception at getProperties" + e.getMessage());
        }
        return config;
    }
}
