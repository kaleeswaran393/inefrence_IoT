package com.senslytics.datadendron.adapter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;
import com.senslytics.datadendron.adapter.TagBean;
import com.senslytics.datadendron.oraadapter.ORAConnectionFactory;
import com.senslytics.datadendron.utils.PropertiesUtils;

public class BaseFunctions {

    static Logger log = Logger.getLogger(BaseFunctions.class.getName());

    public ArrayList getPiData() {
        String sCSVFile = new File("").getAbsolutePath() + "\\resources\\data_from_pi.csv";
        BufferedReader br = null;
        String emptySpace = "";
        String filepath = new File("").getAbsolutePath();
        System.out.println(filepath + sCSVFile);
        ArrayList arr = new ArrayList();
        try {
            br = new BufferedReader(new FileReader(sCSVFile));

            while ((emptySpace = br.readLine()) != null) {
                String[] stag = emptySpace.split(",");
                TagBean tb = new TagBean(stag[0].trim(), stag[2].trim(), stag[1].trim());
                arr.add(tb);
            }
            br.close();

        } catch (Exception e) {
            log.info("BaseFunctions" + e.getMessage());
            e.printStackTrace();
        } finally {

        }
        return arr;
    }

    public ArrayList getAllTagData(String sComponentName) {
        log.info("In BaseFunctions getAllTagData()");
        ArrayList alDataNOSQL = new ArrayList();
        try {
            ORAConnectionFactory ocf = new com.senslytics.datadendron.oraadapter.ORAConnectionFactory();
            KVStore store = ocf.getKVStore();
            List<Row> myRows = null;

            PropertiesConfiguration prop = new PropertiesUtils().getProperties();

            TableAPI tableAPI = ocf.getTableAPI(store);

            Table tableChild = tableAPI.getTable("pi_sensor.tag_detail");
            PrimaryKey key = tableChild.createPrimaryKey();

            for (int i = 0, j = Integer.parseInt(prop.getString("nosqltagnumber")); i < j; i++) {
                ArrayList alSingleTag = new ArrayList();
                int iTemp = i + 1;
                key.put("tag_name", prop.getString("nosqltagname" + iTemp));

                myRows = tableAPI.multiGet(key, null, null);
                for (Row theRow : myRows) {
                    TagBean tbRow = new TagBean(
                                theRow.get("tag_name").asString().get(),
                                theRow.get("tag_value").asString().get(),
                                theRow.get("tag_time").asString().get());
                    alSingleTag.add(tbRow);
                }
                alDataNOSQL.add(alSingleTag);
            }
        } catch (Exception e) {
            log.info("Exception at BaseFunctions getAllTagData()" + e.getMessage());
        }
        return alDataNOSQL;
    }

    public Integer getMaxTagId(String sTagName, String sTableName) {
        log.info("In BaseFunctions getMaxTagId()");
        Integer iId = null;
        try {
            ORAConnectionFactory ocf = new ORAConnectionFactory();
            KVStore store = ocf.getKVStore();
            List<Row> myRows = null;
            Row theRow = null;

            PropertiesConfiguration prop = new PropertiesUtils().getProperties();

            TableAPI tableAPI = ocf.getTableAPI(store);

            Table tableChild = tableAPI.getTable(sTableName);
            PrimaryKey key = tableChild.createPrimaryKey();
            key.put("tag_name", sTagName);

            myRows = tableAPI.multiGet(key, null, null);
            int iRowSize = myRows.size();
            if (iRowSize > 0) {
                theRow = myRows.get(myRows.size() - 1);
                iId = theRow.get("id").asInteger().get();
            } else {
                iId = new Random().nextInt(10) + 1;
            }

        } catch (Exception e) {
            log.info("Exception at BaseFunctions getAllTagData()" + e.getMessage());
        }
        return iId;
    }
}
