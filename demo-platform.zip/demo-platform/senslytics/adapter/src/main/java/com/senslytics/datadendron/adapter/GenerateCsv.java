package com.senslytics.datadendron.adapter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class GenerateCsv {

    public static void main(String[] args) {
        //generateCsvFile("D:\\test.csv",null); 
    }

    public void generateCsvFile(String sFileName, ArrayList list) {
        try {
            FileWriter writer = new FileWriter(sFileName);

            writer.append("Tag");
            writer.append(',');
            writer.append("Value");
            writer.append(',');
            writer.append("Value");
            writer.append('\n');

            for (Object obj : list) {
                TagBean tag = (TagBean) obj;

                writer.append(tag.getTag() + tag.getValue() + tag.getTime());
                writer.append(',');
                writer.append(tag.getValue());
                writer.append(',');
                writer.append(tag.getTime());
                writer.append('\n');

            }

            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
