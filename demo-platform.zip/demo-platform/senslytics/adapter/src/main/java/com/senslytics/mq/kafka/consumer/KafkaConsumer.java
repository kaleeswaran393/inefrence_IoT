package com.senslytics.mq.kafka.consumer;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;

import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;
import com.senslytics.mq.kafka.utils.JsonUtil;
import com.senslytics.mq.kafka.utils.SomeJson;
import com.senslytics.mq.kafka.utils.NotificationReader;
import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.notification.NotificationBean;

import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
 
public class KafkaConsumer implements Runnable {
    private KafkaStream<byte[], byte[]> m_stream;
    private int m_threadNumber;
 
    public KafkaConsumer(KafkaStream<byte[], byte[]> a_stream, int a_threadNumber) {
    	m_threadNumber = a_threadNumber;
        m_stream = a_stream;
    }
    
    public void notification(int failureval, String tagName, long endDate)  {
        NotificationReader nr = new NotificationReader();
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        String deviceId  = "APA91bGodCnJFmQu0tI-NuaXZSUnPSsETc2C-0EwXu-G9mKdr-CBv62TUtX9XygGEcNUE4mljojXQ1iBq0icESs69Eg46__0NuHnWmy6hUhYiVSkcfZ4NVqx45RwG4lrYs4OgVAz5bOV";
        String deviceId3 = "APA91bEGscS4kHDsjjY0MGfiAR2ctThZDxlHABTJCTThXAoJ4dWWsERdz1mm_bkB9GWYiQsEF-i1WLHqjkf1G3lIBAd2ZpOXspTPbevpW049rmDTOGTbNJv1rKJA7jEmmbj08yJeA9-B";
        String deviceId2 = "APA91bEGscS4kHDsjjY0MGfiAR2ctThZDxlHABTJCTThXAoJ4dWWsERdz1mm_bkB9GWYiQsEF-i1WLHqjkf1G3llBAd2ZpOXspTPbevpW049rmDTOGTbNJv1rKJA7jEmmbj08yJeA9-B";
        
		try {
			DbConn con = new DbConn();
				if (failureval == 1){
					notificationList.add(nr.getNotificationList(tagName,endDate,con));
				}
	        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		for (int j=0;j<notificationList.size();j++){
			System.out.println("123" +notificationList.get(j).getMessage());
			
			if (notificationList.get(j).getMessage() != null){
				System.out.println("Messaging");
				androidPushNotification(deviceId,notificationList.get(j).getMessage());
				androidPushNotification(deviceId3,notificationList.get(j).getMessage());
				androidPushNotification(deviceId2,notificationList.get(j).getMessage());
				System.out.println("Done!!!");
			} else {
				System.out.println("No Messaging");
				androidPushNotification(deviceId,"Hi Selva... The device is failing.. Attention required!!!");
				androidPushNotification(deviceId3,"Alert.. Message is null");
				androidPushNotification(deviceId2,"Alert.. Message is null");
				System.out.println("Done!!!");
			}
			
		}
    }
 
    public void run() {
    	System.out.println("Runningg!!!!!!!!");
        ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
        while (it.hasNext()){
        	String messageStr = new String(it.next().message());
        	System.out.println("Message String is "+ messageStr);
        	SomeJson someJson;
			try {
				someJson = JsonUtil.toObject(messageStr, SomeJson.class);
	            String message = someJson.newField;
	            System.out.println("Message detail: " + message);
	            someJson = JsonUtil.toObject(messageStr, SomeJson.class);
	            JSONObject jsonObject = new JSONObject(message);
	            //JSONObject jsonObject = new JSONObject(messageStr);
	            int fp = jsonObject.getInt("failure_predicted");
	            String tagName = jsonObject.getString("tag_name");
	            long endDate = jsonObject.getLong("tw_end_date");
	            System.out.println("Values are: failure value: " + fp + " tag name: " + tagName + " enddate: "+ endDate);
	            notification(fp, tagName, endDate);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			       	
        }
        //notification(0, "abc", 1234);
        System.out.println("Shutting down Thread: " + m_threadNumber);
    }
    
    public boolean androidPushNotification(String deviceId , String push_message){
    	  try{
    	   final String MESSAGE_KEY = "message";
    	   Result result = null;
    	   Sender sender = new Sender("AIzaSyAq2YdTLIQWMPWv7HmsCVJyJEmsRVRhd-k");
    	   com.google.android.gcm.server.Message message = new com.google.android.gcm.server.Message.Builder().timeToLive(30)
    	     .delayWhileIdle(true).addData(MESSAGE_KEY, push_message).build();
    	   result = sender.send(message, deviceId, 1);
    	   System.out.println(result.getErrorCodeName());
    	   System.out.println(result.toString());
    	   return true;
    	  }catch(Exception e){
    	   e.printStackTrace();
    	  }
    	  return false;
    	 }
}