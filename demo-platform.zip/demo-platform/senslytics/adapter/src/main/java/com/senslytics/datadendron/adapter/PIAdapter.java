/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senslytics.datadendron.adapter;

/**
 *
 * @author sakthi.balaji
 */
public class PIAdapter implements SensorAdapter {

    public Object getData(String query, String sComponentName) throws Exception {
        //System.out.println("TEST 4");
        return new TimeSeriesData(sComponentName).getTimeSeriesData(query, sComponentName);
    }

}
