package com.senslytics.datadendron.adapter;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.sensylitics.datadendron.rpackage.PredictionBean;

public class ConvertJson {

    public static String toJson(PredictionBean bean1) throws JsonGenerationException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(bean1);

    }

    public <T> T toObject(String json, Class<T> type) throws JsonGenerationException,
                JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, type);
    }
}
