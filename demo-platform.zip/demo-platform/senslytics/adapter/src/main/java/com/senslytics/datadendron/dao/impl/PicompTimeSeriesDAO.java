package com.senslytics.datadendron.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.senslytics.datadendron.dp.PIJDBCConnectionFactory;
import com.senslytics.datadendron.dao.TagBean;
import com.senslytics.datadendron.dao.TimeSeriesDAO;
import com.senslytics.datadendron.utils.PropertiesUtils;
import com.senslytics.datadendron.dp.SQLConnectionFactory;

public class PicompTimeSeriesDAO implements TimeSeriesDAO {

	private static final Logger logger = Logger
			.getLogger(PicompTimeSeriesDAO.class);
	Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public PicompTimeSeriesDAO() {

		logger.setLevel(Level.INFO);
	}

	
	// selection on tag basis from picomp2
	public List<TagBean> getPicompTagData(
			String maxSuccessTime, String tagName) {
		Statement statement;
		Connection connection = null;
		ResultSet resultSet;
		List li = new ArrayList();
		String endTime = getCurrentTime();
		try {
			connection = PIJDBCConnectionFactory.getPIJDBCConnection();

			if (connection != null) {
				logger.info("Pulling data from PI");
				statement = connection.createStatement();
				resultSet = statement
						.executeQuery("SELECT tag,value,time FROM picomp2 WHERE  time between '"
								+ maxSuccessTime
								+ "' and '"
								+ endTime
								+ "'  and tag= '"
								+ tagName
								+ "' order by time asc");
				while (resultSet.next()) {
					String tag, value;
					tag = resultSet.getString(1);
					value = Double.toString(resultSet.getDouble(2));
					li.add(new TagBean(tag, value, formatter.format(resultSet
							.getDate(3))));

				}
			}

		} catch (SQLException ex) {
			logger.error("getPicompData()", ex);
			return null;
		} catch (Exception e) {
			logger.error("getPicompData()", e);
			return null;
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					logger.error("getPicompData()", e);
				}
			}
		}

		return li;
	}
	
	public List<TagBean> getPicompData(String maxSuccessTime,int maxRecords){return null;}
	
	public List<TagBean> getPicompData(String maxSuccessTime,String maxRecords){return null;}

	// Select PI current time
	public String getCurrentTime() {
		Statement statement;
		Connection connection = null;
		ResultSet resultSet;
		String date = null;
		try {
			connection = PIJDBCConnectionFactory.getPIJDBCConnection();
			if (connection != null) {
				statement = connection.createStatement();
				resultSet = statement
						.executeQuery("SELECT TOP 1 time FROM picomp2 WHERE  time='*' ");

				if (resultSet.next()) {
					date = formatter.format(resultSet.getDate(1));

				}
			}

		} catch (Exception ex) {
			logger.error("getCurrentTime()", ex);
			return null;
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					logger.error("getCurrentTime()", e);
				}
			}
		}

		return date;
	}

}
