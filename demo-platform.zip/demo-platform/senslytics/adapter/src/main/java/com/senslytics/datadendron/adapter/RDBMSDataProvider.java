package com.senslytics.datadendron.adapter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.senslytics.datadendron.dp.SQLConnectionFactory;

public class RDBMSDataProvider {

	private static final Logger logger = Logger
			.getLogger(RDBMSDataProvider.class);

	public List<String>  getTagList() {

		List<String> tagList = new ArrayList<String>();

		Statement stSql;
		Connection sqlConnection = null;
		ResultSet rsSql;
		try {
			sqlConnection = new SQLConnectionFactory().getDBConnection();
			if (sqlConnection != null) {
				logger.info("Pulling tag info from mysql");
				stSql = sqlConnection.createStatement();
				rsSql = stSql
						.executeQuery("select Tag_ID from tag ");
				while (rsSql.next()) {
					tagList.add(rsSql.getString(1));
				}
				
			}

		} catch (SQLException ex) {
			logger.error("getTagList()", ex);
			return null;
		}
		return tagList;
	}

	public List getTagList(String equipmentName) {

		List tagList = new ArrayList<String>();

		return tagList;
	}

	public List getTagList(String[] equipmentName) {

		List tagList = new ArrayList<String>();

		return tagList;
	}
	
	public void updateCurrentValues(String tag, String currentValue) {
	       try{
				Connection con=new SQLConnectionFactory().getDBConnection();
	    	    Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from tag where Tag_ID='" + tag
						+ "'");
				if (rs.last()) {
					Statement stup = con.createStatement();
					
					stup.executeUpdate("update tag set Current_Value='" + currentValue
							+ "'  where  Tag_ID='" + tag + "'");
					stup.close();
				}
			}catch(Exception e){
				System.out.println("Error::" + e);
				
			}

		}

}
