package com.senslytics.datadendron.adapter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import java.util.concurrent.Executors;

import java.util.concurrent.TimeUnit;

import java.util.concurrent.ExecutorService;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.senslytics.datadendron.scheduler.ComponentThread;
import com.senslytics.datadendron.dp.SQLConnectionFactory;
import com.senslytics.datadendron.utils.PropertiesUtils;

public class PiROraManager implements Job {

    static Logger log = Logger.getLogger(PiROraManager.class.getName());

    public void execute(JobExecutionContext context)
                throws JobExecutionException {
        log.info("In PiROraManager execute()");
        Connection sqlConnection = null;
        Statement stSql;
        ResultSet rsSql = null;
        try {
            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            sqlConnection = new SQLConnectionFactory().getDBConnection();
            stSql = sqlConnection.createStatement();
            List<String> lComponentNames = new ArrayList();
            String sql = "select Equipment_List_ID from equipments where Equipment_List_ID in ('BPESP1','BPGLC1' )";
            rsSql = stSql.executeQuery(sql);
            //      where Equipment_List_ID='BPESP1'
            //	System.out.println(sql);
            while (rsSql.next()) {
                lComponentNames.add(rsSql.getString(1));
            }
            log.log(Level.ALL, "Output###################" + lComponentNames.toString());
            ExecutorService executor = Executors.newFixedThreadPool(lComponentNames.size());
            for (int i = 0, j = lComponentNames.size(); i < j; i++) {
                if (Integer.parseInt(prop.getString(lComponentNames.get(i) + "tagnumber")) > 0) {
                    Runnable task = new ComponentThread(lComponentNames.get(i));
                    executor.execute(task);
                } else {
                    System.out.println("Equipment " + lComponentNames.get(i) + " has no data configured");
                }
            }
            shutDownProcess(prop, executor);
        } catch (Exception e) {
            log.info("Exception at PiROraManager execute()" + e.getMessage());
        }
    }

    private void shutDownProcess(PropertiesConfiguration prop,
                ExecutorService executor) throws InterruptedException {
        executor.shutdown();
        if (!executor.awaitTermination(Integer.parseInt(prop.getString("waitTime")), TimeUnit.MINUTES)) {
            log.info("Unable to finish thread execution in " + Integer.parseInt(prop.getString("waitTime")) + " minutes");
        }
    }
}
