package com.senslytics.datadendron.adapter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;
import com.senslytics.datadendron.adapter.TagBean;
import com.senslytics.datadendron.dao.DataStore;
import com.senslytics.datadendron.scheduler.FailureComponentThread;
import com.senslytics.datadendron.utils.PropertiesUtils;
import com.senslytics.datadendron.dp.SQLConnectionFactory;
import com.senslytics.datadendron.oraadapter.ORAConnectionFactory;

public class RManager extends DataStore implements Job {

    static Logger log = Logger.getLogger(RManager.class.getName());

    @Override
    public ArrayList getData(String sComponentName) {
        log.info("In RManager getData()");
        ArrayList alTagDataNOSQL = new ArrayList();
        try {
            ORAConnectionFactory ocf = new ORAConnectionFactory();
            KVStore store = ocf.getKVStore();
            List<Row> myRows = null;

            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            //FileInputStream fs= new FileInputStream("resources\\config.properties");
            //prop.load(fs);

            for (int i = 0, j = Integer.parseInt(prop.getString(sComponentName + "tagnumber"));
                        i < j;
                        i++) {
                ArrayList alDataNOSQL = new ArrayList();
                TableAPI tableAPI = ocf.getTableAPI(store);

                Table tableChild = tableAPI.getTable("tag.sensor_reading");
                int iTemp = i + 1;
                PrimaryKey key = tableChild.createPrimaryKey();
                String sTagName = prop.getString(sComponentName + "tag" + iTemp);
                System.out.println(sComponentName + "tag" + iTemp + " :" + sTagName);
                key.put("tag_name", sTagName);
                //   System.out.println(prop.getProperty("nosqltagname"+iTemp));
                FieldRange fh = tableChild.createFieldRange("tag_time");
                fh.setStart(prop.getString(sTagName + "_start"), true);
                fh.setEnd(prop.getString(sTagName + "_end"), true);
                MultiRowOptions mro = fh.createMultiRowOptions();

                TableIterator<Row> iter = tableAPI.tableIterator(key, mro, null);

                while (iter.hasNext()) {
                    Row row = iter.next();
                    TagBean tbRow = new TagBean(
                                row.get("tag_name").asString().get(),
                                row.get("tag_value").asString().get(),
                                row.get("tag_time").asString().get());
                    alDataNOSQL.add(tbRow);
                }
                alTagDataNOSQL.add(alDataNOSQL);
            }
        } catch (Exception e) {
            log.info("Exception at RManager getData()" + e.getMessage());
        }
        return alTagDataNOSQL;
    }

    @Override
    public void insertData(ArrayList oraData, KVStore store) {
        // TODO Auto-generated method stub

    }

    @Override
    public void execute(JobExecutionContext context)
                throws JobExecutionException {
        log.info("In RManager execute()");
        Connection sqlConnection = null;
        Statement stSql;
        ResultSet rsSql = null;
        try {
            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            sqlConnection = new SQLConnectionFactory().getDBConnection();
            stSql = sqlConnection.createStatement();
            List<String> lComponentNames = new ArrayList();
            String sql = "select Equipment_List_ID from equipments where Equipment_List_ID in ('BPESP1','BPGLC1' )";
            rsSql = stSql.executeQuery(sql);// where Equipment_List_ID='BPESP1'
            //	System.out.println(sql);
            while (rsSql.next()) {
                lComponentNames.add(rsSql.getString(1));
            }
            ExecutorService executor = Executors.newFixedThreadPool(lComponentNames.size());
            for (int i = 0, j = lComponentNames.size(); i < j; i++) {
                if (Integer.parseInt(prop.getString(lComponentNames.get(i) + "tagnumber")) > 0) {
                    Runnable task = new FailureComponentThread(lComponentNames.get(i));
                    executor.execute(task);
                } else {
                    System.out.println("Equipment " + lComponentNames.get(i) + " has no data configured");
                }
            }
            shutDownProcess(prop, executor);

        } catch (Exception e) {
            log.info("Exception at RManager execute()" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void shutDownProcess(PropertiesConfiguration prop,
                ExecutorService executor) throws InterruptedException {
        executor.shutdown();
        if (!executor.awaitTermination(Integer.parseInt(prop.getString("waitTime")), TimeUnit.MINUTES)) {
            log.info("Unable to finish thread execution in " + Integer.parseInt(prop.getString("waitTime")) + " minutes");
        }
    }
}
