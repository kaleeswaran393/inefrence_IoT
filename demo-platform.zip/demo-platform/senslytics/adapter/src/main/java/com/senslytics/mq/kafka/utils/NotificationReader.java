package com.senslytics.mq.kafka.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.notification.NOSQLConnectionFactory;
import com.senslytics.webservice.notification.NotificationBean;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;


public class NotificationReader {
	static Logger log=Logger.getLogger(NotificationReader.class.getName());
	
	NOSQLConnectionFactory ncf = new NOSQLConnectionFactory();
	private KVStore store=ncf.getKVStore();
	DateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public NotificationBean readinTimeRange(NotificationBean bean,long toDate,String tagId) {
		long fromDate=getBackHour(toDate);
		int minValue=bean.getMinValue();
		int maxValue=bean.getMaxValue();
		int outOfRange=0;
		String message = null;
		long firstDate = 0;
		TableAPI tableAPI = ncf.getTableAPI(store);
		
		Table tableChild = tableAPI.getTable("tag.sensor_reading");//GSA_VE11156Y
        PrimaryKey key=tableChild.createPrimaryKey();
        key.put("tag_name", tagId);
        
        FieldRange range=tableChild.createFieldRange("tag_time");
        range.setStart(fromDate, true);
        range.setEnd(toDate, true);
        MultiRowOptions mro =range.createMultiRowOptions();
        TableIterator<Row> iter=tableAPI.tableIterator(key,mro,null);
        System.out.println("Getting tag value");
        while(iter.hasNext()){
        	Row row=iter.next();
        	if((Double.valueOf(row.get("tag_value").asString().get())<minValue)||((Double.valueOf(row.get("tag_value").asString().get())>maxValue))){
        		if(outOfRange==0){
        			firstDate=row.get("tag_time").asLong().get();
        			bean.setFirstTimeOutOfRange(firstDate);
        		}
        		outOfRange+=1;
        	}
        }
        bean.setNoOfOutRange(outOfRange);
        Date date = new Date(bean.getFirstTimeOutOfRange());
        //DateFormat formatter = new SimpleDateFormat("HH:mm:ss:SSS");
        String dateFormatted = formater.format(date);
        if (bean.getFirstTimeOutOfRange()!= 0){
        	message = bean.getEquipmentCategory() + " " + bean.getEquipmentName() +" "+ bean.getSensorName() + " in "+ bean.getLocationName() 
        			+ " Location has been going out of range infrequently. In last 1 hour it has been gone " + outOfRange 
        			+ " times out of range.First time it went out of range at "+ dateFormatted;
        }
        bean.setMessage(message);
        return bean;
	}
	
	public NotificationBean getNotificationList(String tagName,long endDate, DbConn con){
        NotificationBean bean = null;
		bean = con.getMetaData(tagName);
        bean = readinTimeRange(bean,endDate,tagName);        	
        
        return bean;
    }
	
	public long getBackHour(long date){
		return date - 3600000;
	}

}
