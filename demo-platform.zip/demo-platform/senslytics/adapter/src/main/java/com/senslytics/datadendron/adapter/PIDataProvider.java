package com.senslytics.datadendron.adapter;

import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;



import com.senslytics.datadendron.dao.impl.PicompTimeSeriesDAO;
import com.senslytics.datadendron.utils.DateUtils;
import com.senslytics.datadendron.utils.PropertiesUtils;
import com.senslytics.datadendron.dao.TagBean;
/*
 * PIDataProvider */
public class PIDataProvider {
	private static final Logger logger = Logger
			.getLogger(PicompTimeSeriesDAO.class);
	String maxSuccessTime;
	String tagName;
	long maxThresholdLimit = 0;
	String thresholdUnit;
	PicompTimeSeriesDAO piDAO;
	PropertiesConfiguration property;

	public PIDataProvider(String tagName) {
		logger.setLevel(Level.INFO);
		this.tagName = tagName;
		try {
			
			property = new PropertiesUtils()
					.getProperties("sliding-interval.checkpoint." + tagName);

			maxSuccessTime = property.getString("maxSuccessTime");

			maxThresholdLimit = Long.valueOf(property
					.getLong("threshold-value"));
			thresholdUnit = property.getString("threshold-unit");
			
		} catch (Exception e) {
			logger.error("While processing tag " + tagName+ " Property Error " + e);
		}

	}

	public List getTimeSeriesData(String sComponentName) {
		List li = null;
		long threshold = 0;
		String piCurrentTime = null;
		piDAO = new PicompTimeSeriesDAO();
		if (property != null) {
			piCurrentTime = piDAO.getCurrentTime();

			if (piCurrentTime != null) {

				// *******threshold calculation*******

				if (thresholdUnit.equalsIgnoreCase("h")) {
					threshold = new DateUtils(maxSuccessTime, piCurrentTime)
							.getHourDifference();
				} else if (thresholdUnit.equalsIgnoreCase("m")) {
					threshold = new DateUtils(maxSuccessTime, piCurrentTime)
							.getMinutesDifference();

				} else if (thresholdUnit.equalsIgnoreCase("d")) {
					threshold = new DateUtils(maxSuccessTime, piCurrentTime)
							.getDaysDifference();
				}

				if (threshold < maxThresholdLimit) {
					li = piDAO.getPicompTagData(maxSuccessTime, sComponentName);
					if ((li != null)) {

						// //// logging and updating successful data fetch
						TagBean tag = (TagBean) li.get(li.size() - 1);
						try {
							property = new PropertiesUtils()
									.getProperties("sliding-interval.checkpoint."
											+ tagName);
							

							property.setProperty("maxSuccessTime",
									tag.getTime());
							property.save("sliding-interval.checkpoint."
									+ tagName);
							logger.info("'" + li.size() + "'  records b/w '"
									+ maxSuccessTime + "'   '" + tag.getTime()
									+ "'" + "for tag " + tagName);

						} catch (ConfigurationException e) {
							logger.error(
									" getTimeSeriesData()-configuration  failed",
									e);
						}
						try {
							// Update current readings from PI in
							// metadata(MySQL)
							new Thread(new MetadataUpdater(li)).start();

						} catch (Exception e) {
							logger.error("metadata updater processing error "
									+ e);
						}

					} else {
						// / logging data fetch failure
						logger.error("data fetch failed maxTime @ '"
								+ maxSuccessTime + "'");
					}
				} else {
					// MAX_INTERVAL_DELAY as error in log
					System.out.println("MAX_INTERVAL_DELAY as error in log "
							+ sComponentName);

					logger.error("For tag " + sComponentName
							+ " MAX_INTERVAL_DELAY of " + threshold);

					// Setting current time from PI server as maxSuccessTime
					try {
						property.setProperty("maxSuccessTime", piCurrentTime);
						property.save("sliding-interval.checkpoint." + tagName);

					} catch (ConfigurationException e) {
						logger.error(
								" Setting current time from PI server as maxSuccessTime configuration  failed",
								e);
					}
				}
			} else {
				// PI Connectivity error
				logger.error("While processing tag " + sComponentName
						+ " PI CONNECTION ISSUE ");
			}

		} else {
			// No proerty file for tag
			logger.error("No proerty sliding-interval.checkpoint for tag"
					+ sComponentName);
		}
		return li;
	}

}
