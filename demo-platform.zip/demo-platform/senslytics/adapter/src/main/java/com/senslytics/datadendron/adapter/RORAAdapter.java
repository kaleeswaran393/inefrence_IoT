package com.senslytics.datadendron.adapter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Logger;

import org.codehaus.jackson.map.ObjectMapper;

import oracle.kv.KVStore;
import oracle.kv.table.ArrayValue;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import com.senslytics.datadendron.oraadapter.*;
import com.senslytics.datadendron.dao.DataStore;
import com.sensylitics.datadendron.rpackage.PredictionBean;

public class RORAAdapter extends DataStore {

    static Logger log = Logger.getLogger(RORAAdapter.class.getName());

    @Override
    public ArrayList getData(String sComponentName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void insertData(ArrayList alRPredict, KVStore store) {
        log.info("In RORAAdapter insertData method");
        try {
            Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            ORAConnectionFactory ocf = new ORAConnectionFactory();
            store = ocf.getKVStore();

            TableAPI tableAPI = ocf.getTableAPI(store);

            Table tableParent = tableAPI.getTable("tag");
            Table tableChild = tableAPI.getTable("tag.failure_prediction");
            Row rowParent = tableParent.createRow();
            Row rowChild = tableChild.createRow();

            System.out.println("Total Rows" + alRPredict.size());

            for (int i = 0, j = alRPredict.size(); i < j; i++) {
                ObjectMapper mapper = new ObjectMapper();
                PredictionBean bean1 = (PredictionBean) alRPredict.get(i);
                String a = ConvertJson.toJson(bean1);
                System.out.println(a);
            }

            for (int i = 0, j = alRPredict.size(); i < j; i++) {
                PredictionBean bean = (PredictionBean) alRPredict.get(i);

                rowParent.put("tag_name", bean.getTag_name());

                rowChild.put("tag_name", bean.getTag_name());
                rowChild.put("failure_predicted", bean.getFailure_predicted());
                rowChild.put("tw_start_date", bean.getTw_start_date());
                rowChild.put("tw_end_date", bean.getTw_end_date());

                ArrayValue av = rowChild.putArray("time_frames");
                av.add(bean.getTime_frames());

//		    	rowChild.put("data_points", bean.getData_points());
                tableAPI.putIfAbsent(rowChild, null, null);
                tableAPI.putIfAbsent(rowParent, null, null);
            }
            System.out.println("Write Successful!!");
        } catch (Exception e) {
            log.info("Exception at RORAAdapter insertData method " + e.getMessage());
        }
    }

}
