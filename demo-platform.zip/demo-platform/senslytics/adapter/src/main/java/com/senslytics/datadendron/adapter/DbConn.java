package com.senslytics.datadendron.adapter;


import com.senslytics.webservice.model.database.Parameters;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;


public class DbConn {
    
    static Logger log = Logger.getLogger(DbConn.class.getName());

    Connection con;
    Statement st;
    ResultSet rs;

    public DbConn()   {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://20.0.0.6:3306/sensuite", "root", "password");
            st = (Statement) con.createStatement();
        } catch (Exception e) {
            System.out.println("Error::" + e);
        }
    }

    public void updateCurrentValues(String tag, String currentValue) {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from tag where Tag_ID='" + tag + "'");
            if (rs.last()) {
                Statement stup = con.createStatement();
                stup.executeUpdate("update tag set Current_Value='" + currentValue + "'  where  Tag_ID='" + tag + "'");
                stup.close();
            }
        } catch (Exception e) {
            System.out.println("Error::" + e);
        }
    }

    public Parameters selectTagDetails(String tag) {
        Statement st = null;
        ResultSet rs = null;
        Parameters tagDetails = null;
        try {
            st = con.createStatement();
            rs = st.executeQuery("select * from tag where Tag_ID='" + tag + "'");
            if (rs.next()) {
                 tagDetails = new Parameters();
                 tagDetails.setId(rs.getString(1));
                 tagDetails.setCurrentValue(rs.getLong(4));
                 tagDetails.setMaximumValue(rs.getLong(5));
                 tagDetails.setMinimumValue(rs.getLong(6));
                 
            }
        } catch (SQLException ex) {
             log.error(ex.getMessage());
        } finally {
            try {
                st.close();
                rs.close();
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }
               
        }
        return tagDetails;
    }

}
