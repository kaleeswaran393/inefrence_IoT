package com.senslytics.datadendron.adapter;

import java.io.IOException;

import com.sensylitics.datadendron.rpackage.PredictionBean;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

    private ObjectMapper mapper = new ObjectMapper();

    public String toJson(PredictionBean o) throws IOException {
        return mapper.writeValueAsString(o);
    }

    public <T> T toObject(String json, Class<T> type) throws JsonGenerationException,
                JsonMappingException, IOException {
        return mapper.readValue(json, type);
    }

}
