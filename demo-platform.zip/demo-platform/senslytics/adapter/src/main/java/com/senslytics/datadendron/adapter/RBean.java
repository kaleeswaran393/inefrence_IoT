package com.senslytics.datadendron.adapter;

public class RBean {

    private String[] timeseries;
    private double[] value;
    private int prediction;
    private String tag_name;

    public RBean(String[] timeseries, double[] value, int prediction, String tag_name) {

        this.timeseries = timeseries;
        this.value = value;
        this.prediction = prediction;
        this.tag_name = tag_name;
    }

    public String[] getTimeseries() {
        return timeseries;
    }

    public void setTimeseries(String[] timeseries) {
        this.timeseries = timeseries;
    }

    public double[] getValue() {
        return value;
    }

    public void setValue(double[] value) {
        this.value = value;
    }

    public int getPrediction() {
        return prediction;
    }

    public void setPrediction(int prediction) {
        this.prediction = prediction;
    }

    public String getTag_name() {
        return tag_name;
    }

    public void setTag_name(String tag_name) {
        this.tag_name = tag_name;
    }
}
