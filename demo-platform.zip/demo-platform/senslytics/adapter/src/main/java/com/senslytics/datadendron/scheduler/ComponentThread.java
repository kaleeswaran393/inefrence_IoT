package com.senslytics.datadendron.scheduler;

import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;

import oracle.kv.KVStore;
import com.senslytics.datadendron.adapter.PIDataManager;
import com.senslytics.datadendron.adapter.TagBean;
import com.senslytics.datadendron.adapter.ORADataManager;
import com.sensylitics.datadendron.rpackage.RAdapter;
import com.senslytics.datadendron.adapter.RORAAdapter;
import com.senslytics.datadendron.utils.PropertiesUtils;

public class ComponentThread implements Runnable {

    static Logger log = Logger.getLogger(ComponentThread.class.getName());
    private String sComponentName;

    public ComponentThread(String sComponent) {
        this.sComponentName = sComponent;
    }

    public void run() {
        System.out.println("Thread Entry");
        ArrayList alPiData = new ArrayList();
        KVStore store = null;
        try {
            alPiData = new PIDataManager().getData(sComponentName);
            new ORADataManager().insertData(alPiData, store);

            ArrayList alTimeSeries = new ArrayList();
            ArrayList alValues = new ArrayList();

            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            String[] sTagNames = new String[Integer.parseInt(prop.getString(sComponentName + "tagnumber"))];

            for (int i = 0, j = Integer.parseInt(prop.getString(sComponentName + "tagnumber")); i < j; i++) {
                int iTemp = i + 1;
                String sTagNameTemp = prop.getString(sComponentName + "tag" + iTemp);
                sTagNames[i] = sTagNameTemp;
            }
            Integer isDataFailure = 0;
            ArrayList alRPredict = new RAdapter().insertData(alTimeSeries, alValues, sTagNames, sComponentName, isDataFailure);
            new RORAAdapter().insertData(alRPredict, store);
            System.out.println("Thread Exit");
        } catch (Exception e) {
            e.printStackTrace();
            log.info("Exception at ComponentThread " + e.getMessage());
        }
    }
}
