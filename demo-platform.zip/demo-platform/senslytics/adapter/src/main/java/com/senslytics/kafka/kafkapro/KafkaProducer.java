package com.senslytics.kafka.kafkapro;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class KafkaProducer {

    public static void simple(String msg) {

        Properties props = new Properties();
        props.put("metadata.broker.list", "192.168.1.16:9092");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");
        ProducerConfig config = new ProducerConfig(props);
        Producer<String, String> kafkaProducer = new Producer<String, String>(
                    config);
        //String msg = "it coming.....fdsfsfsd.fds.fds.fds";
        KeyedMessage<String, String> keyedMessage = new KeyedMessage<String, String>(
                    "text", msg);
        System.out.println(msg);

        kafkaProducer.send(keyedMessage);

        System.out.println("message sent");

    }
    public static void main(String arg[]){
         KafkaProducer.simple("hi");
     }
}
