/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senslytics.datadendron.adapter;

import java.util.List;

import org.apache.log4j.Logger;

/**
 *
 * @author sakthi.balaji
 */
public class TestAdapter {

    private static final Logger logger = Logger
                .getLogger(TestAdapter.class);

    public static void main(String[] arg) {

        PIAdapter adapter = new PIAdapter();

        try {
            List li = (List) adapter.getData("", "");
            if (li != null) {
                System.out.println(li.size());
                for (Object obj : li) {

                    TagBean tag = (TagBean) obj;

                //System.out.println(tag.getTag()+"   "+tag.getValue()+"     "+tag.getTime());
                }
            }
        } catch (Exception ex) {
            logger.error("data fetch failed");
        }

    }

}
