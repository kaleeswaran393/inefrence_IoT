package com.senslytics.datadendron.adapter;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public interface JobProcessor extends Job {

    void execute(JobExecutionContext context) throws JobExecutionException;

}
