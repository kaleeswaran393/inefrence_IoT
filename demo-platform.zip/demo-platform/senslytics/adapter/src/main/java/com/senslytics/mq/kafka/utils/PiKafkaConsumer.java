package com.senslytics.mq.kafka.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



import org.apache.log4j.Logger;

import kafka.consumer.ConsumerIterator;

import com.fasterxml.jackson.core.type.TypeReference;
import com.senselytics.inference.mq.MessageReceiverHandler;
import java.util.Date;
//import com.fasterxml.jackson.databind.ObjectMapper;

import kafka.consumer.KafkaStream;
 
public class PiKafkaConsumer implements Runnable {
    private KafkaStream<byte[], byte[]> m_stream;
    private int m_threadNumber;
    static Logger log = Logger.getLogger(PiKafkaConsumer.class.getName());
    private String group_Id;
 
    public PiKafkaConsumer(KafkaStream<byte[], byte[]> a_stream, int a_threadNumber, String a_group_Id) {
    	m_threadNumber = a_threadNumber;
        m_stream = a_stream;
        group_Id = a_group_Id;
    }
    
    public void run() {
    	System.out.println("Runningg!!!!!!!!");
    	
        ConsumerIterator<byte[], byte[]> it = m_stream.iterator();
        while (it.hasNext()){
        	String messageStr = new String(it.next().message());
        	System.out.println("Message String is "+ messageStr);
        	try {
        		//ObjectMapper mapper = new ObjectMapper();
        		Map<String, List<TagBean>> map = new HashMap<String, List<TagBean>>();
        		//map = mapper.readValue(messageStr, new TypeReference<Map<String, List<TagBean>>>(){});
        		map = JsonUtil.toObject(messageStr, new TypeReference<Map<String, List<TagBean>>>(){});
				
	            if (group_Id.equalsIgnoreCase("prediction_group")){
	            	System.out.println("Going for pediction piece");
	            } else if (group_Id.equalsIgnoreCase("rules_group")){
                         for(Map.Entry<String, List<TagBean>> entry : map.entrySet())
 		          for(TagBean tagBean:  entry.getValue() ){
                                  MessageReceiverHandler.getInstance().receiveEvent( tagBean.getTag(), Integer.parseInt(tagBean.getValue()),new Date(Long.parseLong(tagBean.getTime())));
                              }
	            	
	            }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage());
			}      	
        }
        System.out.println("Shutting down Thread: " + m_threadNumber);
    }
}