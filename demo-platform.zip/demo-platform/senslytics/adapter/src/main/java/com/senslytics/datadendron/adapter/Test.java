package com.senslytics.datadendron.adapter;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

public class Test {

    public static void main(String[] arg) {

        final PropertiesConfiguration config = new PropertiesConfiguration();
        final String PROPERTIES_FILE_NAME = "query-filter.properties";
        try {
            config.load(PROPERTIES_FILE_NAME);
            config.setProperty("query.maxSuccessTime", "2015-07-16 01:53:49");
            config.save(PROPERTIES_FILE_NAME);
        } catch (ConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
