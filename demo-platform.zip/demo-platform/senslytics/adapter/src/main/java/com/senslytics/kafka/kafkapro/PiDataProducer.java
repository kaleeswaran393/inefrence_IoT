package com.senslytics.kafka.kafkapro;

import java.util.Properties;

import org.apache.log4j.Logger;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;

public class PiDataProducer {

    static Logger log = Logger.getLogger(PiDataProducer.class.getName());

    public static void sendPiData(String piDataJson) {
        Properties props = new Properties();
        props.put("metadata.broker.list", "20.0.0.6:9092");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");
        props.put("zookeeper.session.timeout.ms", "40000");
        props.put("zookeeper.sync.time.ms", "2000");
        props.put("auto.commit.interval.ms", "1000");        
        ProducerConfig config = new ProducerConfig(props);
        Producer<String, String> kafkaProducer = new Producer<String, String>(config);
        //String piDataJson = "it coming.....PI raw data table ..... list Per Tag";
        KeyedMessage<String, String> keyedMessage = new KeyedMessage<String, String>("sensor_readings", piDataJson);
        kafkaProducer.send(keyedMessage);
        log.info("PiDataProducer - successful message published sensor_readings topic");

    }

    public static void main(String arg[]) {
        PiDataProducer.sendPiData("hi");
    }
}
