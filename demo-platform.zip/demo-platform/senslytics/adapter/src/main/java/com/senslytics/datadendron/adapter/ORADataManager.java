package com.senslytics.datadendron.adapter;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import oracle.kv.KVStore;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import com.senslytics.datadendron.dao.DataStore;
import com.senslytics.datadendron.oraadapter.ORAConnectionFactory;

/*
 * This Class gets Data From PI NOSQL DataBase
 *
 */
public class ORADataManager extends DataStore {

    static Logger log = Logger.getLogger(ORADataManager.class.getName());

    @Override
    public ArrayList getData(String sComponentName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void insertData(ArrayList data, KVStore store) {
        log.info("In ORADataManager insertData method");
        try {
            ORAConnectionFactory ocf = new ORAConnectionFactory();
            store = ocf.getKVStore();

            TableAPI tableAPI = ocf.getTableAPI(store);

            Table tableParent = tableAPI.getTable("tag");
            Table tableChild = tableAPI.getTable("tag.sensor_reading");

            for (int i = 0, j = data.size(); i < j; i++) {
                com.senslytics.datadendron.adapter.TagBean tagBean = (com.senslytics.datadendron.adapter.TagBean) data.get(i);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date dCurr = sdf.parse(tagBean.getTime());

                Row rowParent = tableParent.createRow();
                Row rowChild = tableChild.createRow();

                rowParent.put("tag_name", tagBean.getTag());

                rowChild.put("tag_name", tagBean.getTag());
                rowChild.put("tag_value", tagBean.getValue());
                rowChild.put("tag_time", new Timestamp(dCurr.getTime()).getTime());

                tableAPI.putIfAbsent(rowParent, null, null);
                tableAPI.putIfAbsent(rowChild, null, null);
            }
            log.info("In ORADataManager insert complete");
        } catch (Exception e) {
            log.info("Exception at ORADataManager insertData method" + e.getMessage());
        } finally {

        }
    }
}
