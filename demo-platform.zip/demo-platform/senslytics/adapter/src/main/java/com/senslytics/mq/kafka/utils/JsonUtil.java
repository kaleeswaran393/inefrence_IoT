package com.senslytics.mq.kafka.utils;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import com.fasterxml.jackson.core.type.TypeReference;
//import org.codehaus.jackson.map.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

//import com.kafka.queue.PredictionBean;
public class JsonUtil {
	private static ObjectMapper mapper = new ObjectMapper();
	
public static String toJson(Object bean1) throws JsonGenerationException, JsonMappingException, IOException
{
	return mapper.writeValueAsString(bean1);
	
}
public static <T> T toObject(String json, Class<T> type) throws JsonGenerationException,
JsonMappingException, IOException {
   return mapper.readValue(json, type);
}
public static <T> T toObject(String json, TypeReference type)
		throws JsonGenerationException, JsonMappingException, IOException {
	return mapper.readValue(json,type);
}
}

