package com.senslytics.datadendron.adapter;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;

import oracle.kv.KVStore;
import com.senslytics.datadendron.dao.DataStore;

public class PIDataManager extends DataStore implements JobProcessor {

    static Logger log = Logger.getLogger(PIDataManager.class.getName());

    @Override
    public ArrayList getData(String sComponentName) {
        log.info("In PIDataManager getData()");
        ArrayList piData = null;
        BaseFunctions bf = null;
        try {
            bf = new BaseFunctions();
            piData = (ArrayList) new com.senslytics.datadendron.adapter.PIAdapter().getData("SELECT * FROM picomp WHERE  time = '-5m'", sComponentName);
            //piData=bf.getPiData();
        } catch (Exception e) {
            log.info("Exception at PIDataManager getData()" + e.getMessage());
        }
        return piData;
    }

    @Override
    public void insertData(ArrayList pidata, KVStore store) {
		// TODO Auto-generated method stub

    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        log.info("In PIDataManager execute()");
        KVStore store = null;
        try {
            ArrayList piData = getData("");
            new ORADataManager().insertData(piData, store);
        } catch (Exception e) {
            log.info("Exception at PIDataManager execute()" + e.getMessage());
        }
    }
}
