package com.senslytics.datadendron.adapter;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.senslytics.datadendron.dao.TagBean;

public class MetadataUpdater implements Runnable {
	private static final Logger logger = Logger
			.getLogger(MetadataUpdater.class);
	ArrayList<TagBean> pidata;

	public MetadataUpdater(List pidata) {
		this.pidata = (ArrayList<TagBean>) pidata;
	}

	public void run() {

		try {
			RDBMSDataProvider metaDb = new RDBMSDataProvider();

			HashMap<String, String> tagMap = new HashMap<String, String>();
			for (TagBean tag : pidata) {
				tagMap.put(tag.getTag().toString(), tag.getValue().toString());
			}

			Iterator it = tagMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				metaDb.updateCurrentValues(pair.getKey().toString(), pair
						.getValue().toString());
				it.remove(); // avoids a ConcurrentModificationException
			}

		} catch (Exception e) {

			logger.error("MetadataUpdater", e);
			
		}

	}
}
