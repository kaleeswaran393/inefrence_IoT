/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senslytics.datadendron.adapter;

/**
 *
 * @author sakthi.balaji
 */
public class TagBean {

    private String tag;
    private String value;
    private String time;

    public TagBean(String tag, String value, String time) {
        this.tag = tag;
        this.value = value;
        this.time = time;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
