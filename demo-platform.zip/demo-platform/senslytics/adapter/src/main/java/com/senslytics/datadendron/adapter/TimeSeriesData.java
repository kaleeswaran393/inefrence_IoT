/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senslytics.datadendron.adapter;

import com.senselytics.inference.mq.MessageReceiverHandler;
import com.senselytics.inference.rule.FileWriter;
import com.senselytics.inference.rule.RulesEngineCloudMode;
import com.senselytics.inference.vo.Status;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.senslytics.datadendron.dao.impl.PicompTimeSeriesDAO;
import com.senslytics.webservice.model.database.Parameters;
import java.io.IOException;
import java.util.Date;

/**
 *
 * @author sakthi.balaji
 */
public class TimeSeriesData {

    private static final Logger logger = Logger.getLogger(TimeSeriesData.class);
    private static final String PROPERTIES_FILE_NAME = "query-filter.properties";
    private static PropertiesConfiguration config;

    String maxSuccessTime;

    public TimeSeriesData(String sComponentName) {
        logger.setLevel(Level.INFO);
        try {
            config = new PropertiesConfiguration();
            config.load(PROPERTIES_FILE_NAME);
            maxSuccessTime = (String) config
                        .getString("query." + sComponentName);
        } catch (ConfigurationException e) {

            logger.error("query-filter-ConfigurationException", e);
        }
    }

    public Object getTimeSeriesData(String query, String sComponentName) throws IOException {
        //System.out.println("TEST 5");
        List li = new PicompTimeSeriesDAO().getPicompData(maxSuccessTime, sComponentName);

        logger.info("# PiData Size ===>" + li.size());

       // if ((li != null)) {
        for(int i =0;i<=li.size();i++){
            ////// logging and updating successful data fetch
           // TagBean tag = (TagBean) li.get(li.size() - 1);
            TagBean tag = (TagBean) li.get(i);
            try {
                config = new PropertiesConfiguration();
                config.load(PROPERTIES_FILE_NAME);
                config.setProperty("query." + sComponentName,
                            tag.getTime());
                config.save(PROPERTIES_FILE_NAME);
                logger.info("'" + li.size() + "'  records b/w '" + maxSuccessTime + "'   '" + tag.getTime() + "'");

				//new GenerateCsv().generateCsvFile("D:\\test.csv", (ArrayList) li);
                //logger.info("Data fetch success @ '" + maxSuccessTime + "'");
                // new Thread(new MetadataUpdater(li)).start(); 
                               
                new MetadataUpdater(li).run();
              //  MessageReceiverHandler.getInstance().receiveEvent( tag.getTag(), Double.parseDouble(tag.getValue()),new Date());
                
            } catch (ConfigurationException e) {
                logger.error(" getTimeSeriesData()-configuration  failed", e);
            }

        } //else {
            /// logging data fetch failure
          //  logger.error("data fetch failed maxTime @ '" + maxSuccessTime + "'");
       // }

        return li;
    }
}
