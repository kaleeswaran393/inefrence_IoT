package com.senslytics.datadendron.scheduler;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import oracle.kv.KVStore;

import com.senslytics.datadendron.adapter.PIDataManager;
import com.senslytics.datadendron.adapter.TagBean;
import com.senslytics.datadendron.adapter.ORADataManager;
import com.senslytics.datadendron.utils.JsonUtil;
import com.senslytics.kafka.kafkapro.PiDataProducer;
import com.senslytics.datadendron.adapter.PIDataProvider;

public class TagComponentThread implements Runnable {
	static Logger log = Logger.getLogger(TagComponentThread.class.getName());
	private String sComponentName;

	public TagComponentThread(String sComponent) {
		this.sComponentName = sComponent;
	}

	public void run() {
		System.out.println("Thread Entry for Tag--->"+sComponentName);
		ArrayList alPiData = new ArrayList();
		KVStore store = null;
		Map<String, List<TagBean>> map = null;
		
		try {

			
			// selection on tag basis
			alPiData = (ArrayList) new PIDataProvider(sComponentName)
					.getTimeSeriesData(sComponentName);

			// inserting raw data from PI into NoSQL 
			
			if (alPiData != null) {
				new ORADataManager().insertData(alPiData, store);
				map = new HashMap<String, List<TagBean>>();
				map.put(sComponentName, alPiData);
			}else{
				log.info("No data from PI for tag "+sComponentName);
			}

			
			try {
				// PiDataProducer call & Data processing ******* kafka producer
				if(map!=null)
					PiDataProducer.sendPiData(JsonUtil.toJson(map));
			} catch (JsonGenerationException e) {
				log.info("ComponentThread JsonGenerationException"
						+ e.getMessage());
			} catch (JsonMappingException e) {
				log.info("ComponentThread JsonMappingException"
						+ e.getMessage());

			} catch (IOException e) {
				log.info("ComponentThread IOException" + e.getMessage());

			}

			
			System.out.println("Thread Exit");
		} catch (Exception e) {
			log.error("Exception at ComponentThread " + e.getMessage());
		}

	}

}
