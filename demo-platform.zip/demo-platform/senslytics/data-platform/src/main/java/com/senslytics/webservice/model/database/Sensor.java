/**
 *
 */
package com.senslytics.webservice.model.database;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 * @author Prabakaran
 *
 */
public class Sensor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private String id;
    @Column(name = "sensor")
    private String sensore;
    @Column(name = "equipment_id")
    private String equipmentId;
    private EquipmentValueDetail previousValues = new EquipmentValueDetail();

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "parameter_id")
    private Parameters parameter = new Parameters();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSensore() {
        return sensore;
    }

    public void setSensore(String sensore) {
        this.sensore = sensore;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public Parameters getParameter() {
        return parameter;
    }

    public void setParameter(Parameters parameter) {
        this.parameter = parameter;
    }

    public EquipmentValueDetail getPrevValue() {
        return previousValues;
    }

    public void setPrevValue(EquipmentValueDetail prevValue) {
        this.previousValues = prevValue;
    }

}
