package com.senslytics.webservice.model.database;

import java.util.ArrayList;
import java.util.List;

public class EquipmentValueDetail {

    private List<Double> currValue = new ArrayList<Double>();
    private List<String> currTs = new ArrayList<String>();

    public List<Double> getCurrValue() {
        return currValue;
    }

    public void setCurrValue(List<Double> currValue) {
        this.currValue = currValue;
    }

    public List<String> getCurrTs() {
        return currTs;
    }

    public void setCurrTs(List<String> currTs) {
        this.currTs = currTs;
    }

}
