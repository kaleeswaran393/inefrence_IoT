package com.senslytics.datadendron.utils;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.configuration.PropertiesConfiguration;

public class PropertiesUtils {

    public static Logger log = Logger.getLogger(PropertiesUtils.class.getName());

    public PropertiesConfiguration getProperties() {
        log.setLevel(Level.INFO);
        PropertiesConfiguration config = null;
        final String PROPERTIES_FILE_NAME = new File("").getAbsolutePath() + "/src/main/resources/config.properties";
        try {
            config = new PropertiesConfiguration();
            config.load(PROPERTIES_FILE_NAME);
        } catch (Exception e) {
            log.info("Exception at getProperties" + e.getMessage());
        }
        return config;
    }

    public  PropertiesConfiguration getProperties(String fileName) {
        log.setLevel(Level.INFO);
        PropertiesConfiguration config = null;
        try {
            String PROPERTIES_FILE_NAME = new File("").getAbsolutePath() + "/src/main/resources/" + fileName;
            config = new PropertiesConfiguration();
            config.load(PROPERTIES_FILE_NAME);
        } catch (Exception e) {
            log.info("Exception at getProperties" + e.getMessage());
            return null;
        }
        return config;
    }
}
