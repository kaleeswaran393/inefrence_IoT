/**
 *
 */
package com.senslytics.webservice.model.database;

//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//import java.util.TimeZone;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;
//import org.apache.avro.data.Json;

import com.senslytics.webservice.model.restparms.EquipmentNotificationResponse;
import com.senslytics.webservice.model.restparms.EquipmentStatusResponse;
import com.senslytics.webservice.model.restparms.NotificationResponse;
import com.senslytics.webservice.notification.NotificationBean;
import com.senslytics.webservice.webservices.GeographyLocationService;
//import com.sensesuite.model.restparms.EquipmentStatusResponse;
//import com.sensesuite.model.restparms.LocationResponse;
//import com.sensesuite.webservice.NotificationService;
//import com.sensesuite.notification.NotificationBean;
//import com.sensesuite.notification.ParameterDetail;

/**
 * @author Prabakaran
 *
 */
public class ConnectionDb {

    /**
     * @param args
     */
    public static void main(String[] args) {
        //List<GeographyLocation> locationList = new ArrayList<GeographyLocation>();
        /*List<GeographyLocation> response = new ArrayList<GeographyLocation>();
         Set<GeographyLocation> response2 = null;
         LocationResponse res = new LocationResponse();*/
        //List<EquipmentCategory> categoryList = new ArrayList<EquipmentCategory>();
        //List<Sensor> response = new ArrayList<Sensor>();
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        /*List<EquipmentCategory> equimentNotificationList = new ArrayList<EquipmentCategory>();
         */
        List<Sensor> sensor = new ArrayList<Sensor>();
        EquipmentValueDetail prevValue = new EquipmentValueDetail();
        EquipmentStatusResponse res = new EquipmentStatusResponse();
        EquipmentNotificationResponse response = new EquipmentNotificationResponse();
        try {
            /* For method 1*/

            //Long locationId = new Long(1);
            /* For method 2*/
            //categoryList = new DbConn().getEquipment("guest@bp.com", locationId);
            /* For method 3*/
            /*response = new DbConn().getSensors("BPGLC1");
             System.out.println(response.get(0).getParameter().getCurrentValue());
             System.out.println(response.get(0).getParameter().getMaximumValue());
             System.out.println(response.get(0).getParameter().getMinimumValue());*/
            /*System.out.println("Size is "+ categoryList.size());
             for (int a = 0; a <categoryList.size();a++){
             //System.out.println(categoryList.get(a).getEquipmentCategory());
             //System.out.println(categoryList.get(a).getEquipmentCategoryId());
             System.out.println("*************************************************");
             System.out.println("Size of equipments is "+ categoryList.get(a).getEquipments().size());
             /*System.out.println(categoryList.get(a).getEquipments().get(0).getEquipementName());
             System.out.println(categoryList.get(a).getEquipments().get(0).getEquipmentCategoryId());
             System.out.println(categoryList.get(a).getEquipments().get(0).getEquipmentListId());
             System.out.println("*************************************************");*/
            //System.out.println("Size is " +categoryList.get(0).getEquipments().get(0).getSensor().size());
            /*for (int b = 0; b <categoryList.get(a).getEquipments().size();b++){
             System.out.println("Size of sensor is "+ categoryList.get(a).getEquipments().get(b).getSensor().size());
             for (int i=0; i<categoryList.get(a).getEquipments().get(b).getSensor().size(); i++){
             //System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getId());
             //System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getEquipmentId());
             //System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getSensore());
             System.out.println("*************************************************");
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getId());
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getParameter());
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getSensorId());
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getMaximumValue());
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getCurrentValue());
             System.out.println(categoryList.get(a).getEquipments().get(b).getSensor().get(i).getParameter().getMinimumValue());
             System.out.println("*************************************************");
             }}}*/
            /*response = new DbConn().getMember("guest@bp.com");
             response2 = new HashSet<GeographyLocation>(response);
             res.setLocation(response2);
             System.out.println(response.get(0).getCity());
             System.out.println(response.get(0).getCountry());
             System.out.println(response.get(0).getState());
             System.out.println(response.get(0).getLocationId());
             System.out.println(res.getLocation().size());
             for(GeographyLocation p:response2){
             System.out.println(p.getCity());
             System.out.println(p.getCountry());
             System.out.println(p.getState());
             System.out.println(p.getLocationId());
             }*/
            //notificationList = 
            //System.out.println(res.getLocation().iterator().);*/
            NotificationResponse res1 = new NotificationResponse();
            GeographyLocationService t = new GeographyLocationService();
            JSONObject request = new JSONObject();
            request.put("userId", "guest@bp.com");
            res1 = t.equipments(request);
            //response = t.notification(request);
            //System.out.println("Done");
            //System.out.println(response.getNotification().size());
            //System.out.println(equimentNotificationList.size());
            //for (int t1 = 0; t1<response.getNotification().size();t1++){
        	/*System.out.println(response.getNotification().get(t1).getEquipments().get(0).getEquipementName());
             System.out.println(response.getNotification().get(t1).getEquipments().get(0).getEquipmentLocationId());*/
            //	for (int t2 = 0; t2<response.getNotification().get(t1).getEquipments().size();t2++){
            //System.out.println("Message is " + response.getNotification().get(t1).getEquipments().get(t2).getEquipmentDescription());}}
            //System.out.println(response.getNotification().get(t1).getEquipmentCategory());}
        	/*System.out.println("Size of sensor is " + response.getNotification().get(0).getEquipments().get(0).getSensor().size());
             for (int t2 = 0; t2<response.getNotification().get(0).getEquipments().get(0).getSensor().size();t2++){
             System.out.println(response.getNotification().get(t1).getEquipments().get(0).getEquipmentDescription());
             System.out.println(response.getNotification().get(t1).getEquipments().get(0).getSensor().get(t2).getParameter().getCurrentValue());
             System.out.println(response.getNotification().get(t1).getEquipments().get(0).getSensor().get(t2).getParameter().getMaximumValue());
             System.out.println(response.getNotification().get(t1).getEquipments().get(0).getSensor().get(t2).getParameter().getMinimumValue());
             }}/*TimeZone fromTZ = TimeZone.getTimeZone("IST"); 
             TimeZone toTZ = TimeZone.getTimeZone("EST");
             new ParameterDetail();
             String toDate1 = ParameterDetail.convertTimeZone("2015-07-19 19:00:00", fromTZ, toTZ);
             //System.out.println(toDate1);
             //String newDate = toDate1.toString();*/

            for (int t1 = 0; t1 < res1.getNotification().size(); t1++) {
                System.out.println("Message is " + res1.getNotification().get(t1).getMessage());
            }

            JSONObject req = new JSONObject();
            req.put("EquipmentId", "BPGLC1");
            req.put("currenttime", "2015-10-29 19:00:00");
            req.put("hours", "24");
            req.put("timezone", "IST");
            /*sensor = new DbConn().getSensors(req.getString("EquipmentId"));
             String toDate = req.getString("currenttime");
             int hours = req.getInt("hours");
             TimeZone fromTz= TimeZone.getTimeZone(req.get("timezone").toString());
             //sensor = new DbConn().getSensors("BPGLC1");
             System.out.println("Length of sensors is "+ sensor.size());*/
            //String toDate = "2015-07-19 19:00:00";
            //int hours = 24;
    		/*for (int i=0; i<sensor.size(); i++){
             prevValue = new ParameterDetail().readinTimeRange(sensor.get(i).getParameter().getId(), toDate,fromTz,hours);
             System.out.println("Length is "+prevValue.getCurrValue().size());
             sensor.get(i).setPrevValue(prevValue);
             for (int j= 0; j<prevValue.getCurrValue().size(); j++){
             System.out.println("Value is "+prevValue.getCurrValue().get(j).toString());
             System.out.println("Timestamp is "+prevValue.getCurrTs().get(j).toString());
             }
             }
             //System.out.println("Correct till ere");
             res.setSensor(sensor);
            
             //System.out.println(newDate);*/
            /*GeographyLocationService s = new GeographyLocationService();
             res = s.equipmentDetail(req);
             System.out.println(res.getSensor().size());
             for (int i=0; i<res.getSensor().size(); i++){
             prevValue = new ParameterDetail().readinTimeRange(sensor.get(i).getParameter().getId(), toDate,fromTz,hours);
             System.out.println("Length is "+res.getSensor().get(i).getPrevValue().getCurrTs().size());
             sensor.get(i).setPrevValue(prevValue);
             for (int j= 0; j<res.getSensor().get(i).getPrevValue().getCurrTs().size(); j++){
             System.out.println("Value is "+res.getSensor().get(i).getPrevValue().getCurrValue().get(j).toString());
             System.out.println("Timestamp is "+res.getSensor().get(i).getPrevValue().getCurrTs().get(j).toString());
             }
             }*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
