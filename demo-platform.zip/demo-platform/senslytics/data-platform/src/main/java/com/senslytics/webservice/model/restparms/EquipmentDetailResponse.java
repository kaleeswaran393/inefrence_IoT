package com.senslytics.webservice.model.restparms;

import java.util.ArrayList;
import java.util.List;
import com.senslytics.webservice.model.database.Sensor;
import com.senslytics.webservice.model.utils.ResponseModel;

public class EquipmentDetailResponse extends ResponseModel {

    List<Sensor> sensor = new ArrayList<Sensor>();

    private String equipmentLocationId;

    public List<Sensor> getCategory() {
        return sensor;
    }

    public void setSensor(List<Sensor> sensor) {
        this.sensor = sensor;
    }

    public String getEquipmentLocationId() {
        return equipmentLocationId;
    }

    public void setEquipmentLocationId(String equipmentLocationId) {
        this.equipmentLocationId = equipmentLocationId;
    }

}
