package com.senslytics.datadendron.dao;

import java.util.ArrayList;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import oracle.kv.KVStore;

public abstract class DataStore {

    public abstract ArrayList getData(String sComponentName);

    public abstract void insertData(ArrayList pidata, KVStore store);

    public void execute(JobExecutionContext context)
                throws JobExecutionException {
        // TODO Auto-generated method stub

    }
}
