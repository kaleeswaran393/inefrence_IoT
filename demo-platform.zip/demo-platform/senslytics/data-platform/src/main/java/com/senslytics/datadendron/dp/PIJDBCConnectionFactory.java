/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senslytics.datadendron.dp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;

//import sensylitics.suit.datadendron.adapter.dao.impl.PicompTimeSeriesDAO;
/**
 *
 * @author sakthi.balaji
 */
public class PIJDBCConnectionFactory {

    private static final Logger logger = Logger
                .getLogger(PIJDBCConnectionFactory.class);
    private static final String PROPERTIES_FILE_NAME = "database.properties";
    private static final PropertiesConfiguration config = new PropertiesConfiguration();
    private static PIJDBCConnectionFactory instance = new PIJDBCConnectionFactory();

    public static String URL;//= "jdbc:pisql://20.0.0.5:5461/Data Source=WIN-R1D1AS081C1 ; Integrated Security=SSPI";
    public static String USER;//= "Administrator";
    public static String PASSWORD;// = "Pass@word1";
    public static String DRIVER_CLASS;// = "com.osisoft.jdbc.Driver";

    private PIJDBCConnectionFactory() {
        try {
            config.load(PROPERTIES_FILE_NAME);
            DRIVER_CLASS = (String) config.getProperty("jdbc.driverClassName");
            URL = (String) config.getProperty("jdbc.url");
            USER = (String) config.getProperty("jdbc.username");
            PASSWORD = (String) config.getProperty("jdbc.password");
        } catch (ConfigurationException e) {
            logger.error("PIJDBC-ConfigurationException", e);
        }
        try {

            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
            logger.error("Driver class error", e);
        }
    }

    private Connection createPIJDBCConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
           // connection = DriverManager.getConnection(URL);
//System.out.println(URL);
//System.out.println(USER);
//System.out.println(PASSWORD);
        } catch (SQLException e) {
            logger.error("createPIJDBCConnection()", e);
            connection = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static Connection getPIJDBCConnection() {
        return instance.createPIJDBCConnection();
    }

}
