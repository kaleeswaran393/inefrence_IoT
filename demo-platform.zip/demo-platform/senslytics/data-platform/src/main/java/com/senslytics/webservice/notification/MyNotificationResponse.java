package com.senslytics.webservice.notification;

import java.util.ArrayList;
import java.util.List;

import com.senslytics.webservice.model.utils.ResponseModel;
import com.senslytics.webservice.notification.NotificationBean;

public class MyNotificationResponse extends ResponseModel {

    public List<NotificationBean> notification = new ArrayList<NotificationBean>();

    public List<NotificationBean> getNotification() {
        return notification;
    }

    public void setNotification(List<NotificationBean> notification) {
        this.notification = notification;
    }

}
