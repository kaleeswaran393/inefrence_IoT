package com.senslytics.datadendron.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	String fromDate;
	String toDate;

	public DateUtils(String fromDate, String toDate) {
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	//MilliSec Difference
	public long getMilliSecDifference() {
		long diff = 0;
		// HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = format.parse(fromDate);
			d2 = format.parse(toDate);

			// in milliseconds
			diff = d2.getTime() - d1.getTime();
			System.out.println(fromDate +"    "+fromDate+"   "+diff);
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return diff;
	}

	//HourDifference
	
	public long getHourDifference() {

		long diffHours = 0;
		diffHours=getMilliSecDifference() / (60 * 60 * 1000) ;
		System.out.println(diffHours);
		return diffHours;

	}
	
	//Minutes Difference
	
	public long getMinutesDifference() {

		long diffMinutes = 0;
		return getMilliSecDifference() / (60 * 1000) ;

	}
	
	// Day Difference
	
	public long getDaysDifference() {

		long diffDays = 0;
		return getMilliSecDifference() / (24 * 60 * 60 * 1000);

	}
	

}
