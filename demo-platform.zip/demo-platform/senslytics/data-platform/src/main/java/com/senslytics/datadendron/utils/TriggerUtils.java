package com.senslytics.datadendron.utils;

import java.util.Date;

import org.quartz.impl.triggers.SimpleTriggerImpl;

public class TriggerUtils extends SimpleTriggerImpl {

    public TriggerUtils(Date startTime, int repeatCount, long repeatInterval, String triggerName) {
        setStartTime(startTime);
        setRepeatCount(repeatCount);
        setRepeatInterval(repeatInterval);
        setName(triggerName);
    }

}
