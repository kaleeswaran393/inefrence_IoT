package com.senslytics.datadendron.dao;

import java.util.ArrayList;

import oracle.kv.KVStore;

public abstract class RDataStore {

    public abstract ArrayList getData();

    public abstract ArrayList insertData(ArrayList strTimeArray, ArrayList strValArray, String[] strTagName, String sComponentName, Integer isDataFailure);
}
