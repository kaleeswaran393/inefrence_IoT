package com.senslytics.datadendron.dao;

import java.util.List;

public interface TimeSeriesDAO {

    public List<TagBean> getPicompData(String maxSuccessTime, String sComponentName);

    public List<TagBean> getPicompData(String maxSuccessTime, int maxRecords);

    public String getCurrentTime();

}
