package com.senslytics.datadendron.utils;

import java.util.logging.Logger;

import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

public class SchedularUtils {

    static Logger log = Logger.getLogger(SchedularUtils.class.getName());
    StdSchedulerFactory factory = null;

    public StdSchedulerFactory getFactory() {
        log.info("In SchedularFactory getFactory()");
        try {
            factory = new StdSchedulerFactory();
        } catch (Exception e) {
            log.info("SchedularFactory" + e.getMessage());
        }

        return factory;
    }

}
