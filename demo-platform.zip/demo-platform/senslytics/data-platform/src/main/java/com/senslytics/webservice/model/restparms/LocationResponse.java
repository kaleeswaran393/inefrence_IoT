/**
 *
 */
package com.senslytics.webservice.model.restparms;

import java.util.HashSet;
import java.util.Set;

import com.senslytics.webservice.model.database.GeographyLocation;
import com.senslytics.webservice.model.utils.ResponseModel;

/**
 * @author Prabakaran
 *
 */
public class LocationResponse extends ResponseModel {

    public Set<GeographyLocation> location = new HashSet<GeographyLocation>();

    public Set<GeographyLocation> getLocation() {
        return location;
    }

    public void setLocation(Set<GeographyLocation> location) {
        this.location = location;
    }

}
