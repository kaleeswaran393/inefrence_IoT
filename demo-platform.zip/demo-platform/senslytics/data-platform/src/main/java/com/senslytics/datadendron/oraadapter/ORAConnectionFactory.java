package com.senslytics.datadendron.oraadapter;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;

import oracle.kv.KVStore;
import oracle.kv.KVStoreConfig;
import oracle.kv.KVStoreFactory;
import oracle.kv.table.TableAPI;
import com.senslytics.datadendron.utils.PropertiesUtils;
import oracle.kv.FaultException;
import oracle.kv.KVStoreException;

public class ORAConnectionFactory {

    static Logger log = Logger.getLogger(ORAConnectionFactory.class.getName());

    public KVStore getKVStore() {
        log.info("In ORAConnectionFactory getKVStore()");
        KVStore store = null;
        try {
            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
            store = KVStoreFactory.getStore(new KVStoreConfig(prop.getString("nosqldbstorename"), prop.getString("nosqldbhostname") + ":" + prop.getString("nosqldbport")));
        } catch (FaultException e) {
            log.info("ORAConnectionFactory unable creating store" + e.getMessage());
        }
        return store;
    }

    public TableAPI getTableAPI(KVStore kvstore) {
        log.info("In ORAConnectionFactory getTableAPI()");
        TableAPI table = null;
        try {
            table = kvstore.getTableAPI();
        } catch (Exception e) {
            log.info("ORAConnectionFactory unable creating TableAPI" + e.getMessage());
        }
        return table;
    }
}
