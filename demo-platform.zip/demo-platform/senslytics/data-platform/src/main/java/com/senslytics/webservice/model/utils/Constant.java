package com.senslytics.webservice.model.utils;

public class Constant {

    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";

    public static final String E0001 = "E0001";

}
