package com.senslytics.datadendron.dp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;

import com.senslytics.datadendron.utils.PropertiesUtils;

public class SQLConnectionFactory {

    static Logger log = Logger.getLogger(SQLConnectionFactory.class.getName());

    public Connection getDBConnection() {
        log.logp(Level.INFO, SQLConnectionFactory.class.getName(), "getDBConnection", "In getDBConnection");
        Connection conn = null;
        try {
            PropertiesConfiguration prop = new PropertiesUtils().getProperties();
//			String sUrl="jdbc:mysql://"+prop.getProperty("mysqlhostname")+":3030/"+prop.getProperty("mysqldbname");
            String sUrl = "jdbc:mysql://localhost:3030/test";
            sUrl = "jdbc:mysql://20.0.0.6/sensuite";
//			System.out.println(sUrl);
            Class.forName("com.mysql.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection(sUrl, prop.getString("mysqlusername"), "password");
            //conn=(Connection)DriverManager.getConnection(sUrl, prop.getString("mysqlusername"),prop.getString("mysqlpassword"));
        } catch (Exception e) {
            log.logp(Level.SEVERE, SQLConnectionFactory.class.getName(), "getDBConnection", "Exception at getDBConnection" + e.getMessage());
            conn = null;
        }
        return conn;
    }
}
