package com.senslytics.webservice.model.database;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

public class EquipmentList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private String equipmentListId;
    @Column(name = "locationId")
    private String equipmentLocationId;
    @Column(name = "equipments_name")
    private String equipementName;
    @Column(name = "equipement_description")
    private String equipementDescription;
    @Column(name = "equipment_category_id")
    private String equipmentCategoryId;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "equipment_id")
    private List<Sensor> sensor = new ArrayList<Sensor>();

    public String getEquipmentCategoryId() {
        return equipmentCategoryId;
    }

    public void setEquipmentCategoryId(String equipmentCategoryId) {
        this.equipmentCategoryId = equipmentCategoryId;
    }

    public String getEquipmentListId() {
        return equipmentListId;
    }

    public void setEquipmentListId(String equipmentListId) {
        this.equipmentListId = equipmentListId;
    }

    public String getEquipmentLocationId() {
        return equipmentLocationId;
    }

    public void setEquipmentLocationId(String equipmentLocationId) {
        this.equipmentLocationId = equipmentLocationId;
    }

    public String getEquipmentDescription() {
        return equipementDescription;
    }

    public void setEquipmentDescription(String equipementDescription) {
        this.equipementDescription = equipementDescription;
    }

    public String getEquipementName() {
        return equipementName;
    }

    public void setEquipementName(String equipementName) {
        this.equipementName = equipementName;
    }

    public List<Sensor> getSensor() {
        return sensor;
    }

    public void setSensor(List<Sensor> sensor) {
        this.sensor = sensor;
    }

}
