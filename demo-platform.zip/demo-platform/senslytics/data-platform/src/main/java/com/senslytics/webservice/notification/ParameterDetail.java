package com.senslytics.webservice.notification;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.logging.Logger;

import com.senslytics.webservice.model.database.EquipmentValueDetail;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;

public class ParameterDetail {

    static Logger log = Logger.getLogger(ParameterDetail.class.getName());
    NOSQLConnectionFactory ncf = new NOSQLConnectionFactory();
    private KVStore store = ncf.getKVStore();

    public EquipmentValueDetail readinTimeRange(String tagId, String toDate, TimeZone fromTz, int hours) throws ParseException {

        String localDate = convertTimeZone(toDate, fromTz, TimeZone.getTimeZone("EST"));
        long toTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(localDate).getTime();
        long fromDate = getBackHour(localDate, hours);
        List<Double> currVal = new ArrayList<Double>();
        List<String> currTimestamp = new ArrayList<String>();
        TableAPI tableAPI = ncf.getTableAPI(store);
        Table tableChild = tableAPI.getTable("tag.sensor_reading");//GSA_VE11156Y
        PrimaryKey key = tableChild.createPrimaryKey();
        key.put("tag_name", tagId);
        FieldRange range = tableChild.createFieldRange("tag_time");
        range.setStart(fromDate, true);
        range.setEnd(toTime, true);
        MultiRowOptions mro = range.createMultiRowOptions();
        TableIterator<Row> iter = tableAPI.tableIterator(key, mro, null);
        EquipmentValueDetail currDetail = new EquipmentValueDetail();
        while (iter.hasNext()) {
            Row row = iter.next();
            currVal.add(Double.valueOf(row.get("tag_value").asString().get()));
            long millisec = row.get("tag_time").asLong().get();
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(millisec);
            DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            currTimestamp.add(convertTimeZone(df1.format(calendar.getTime()), TimeZone.getTimeZone("EST"), fromTz));
        }
        currDetail.setCurrValue(currVal);
        currDetail.setCurrTs(currTimestamp);
        store.close();
        return currDetail;
    }

    public long getBackHour(String date, int hours) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currdate;
        long milli = 0;
        try {
            currdate = df.parse(date);
            milli = currdate.getTime();
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        long from = milli - hours * 60 * 60 * 1000;
        return from;
    }

    public static String convertTimeZone(String date, TimeZone fromTZ, TimeZone toTZ) {
        long fromTZDst = 0;
        long toTZDst = 0;
        long fromTZOffset = 0;
        long toTZOffset = 0;
        String mon = null;
        Date date1 = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date1 = formatter.parse(date);

            if (fromTZ.inDaylightTime(date1)) {
                fromTZDst = fromTZ.getDSTSavings();
            }

            fromTZOffset = fromTZ.getRawOffset() + fromTZDst;

            if (toTZ.inDaylightTime(date1)) {
                toTZDst = toTZ.getDSTSavings();
            }
            toTZOffset = toTZ.getRawOffset() + toTZDst;
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Date returndate = new java.util.Date(date1.getTime() + (toTZOffset - fromTZOffset));
        @SuppressWarnings("deprecation")
        int month = returndate.getMonth() + 1;
        if (month < 10) {
            mon = "0" + Integer.toString(month);
        } else {
            mon = Integer.toString(month);
        }
        String[] splitted = returndate.toString().split(" ");

        String returndate1 = splitted[5] + "-" + mon + "-" + splitted[2] + " " + splitted[3];
        return returndate1;
    }
}
