package com.senslytics.webservice.notification;

public class NotificationBean {

    private String equipmentName;
    private String locationName;
    private String equipmentCategory;
    private String sensorName;
    private String message;
    private long firstTimeOutOfRange;
    private int noOfOutRange;
    private int minValue;

    private int maxValue;
    private int currentValue;

    public NotificationBean(String equipmentName, String locationName, String equipmentCategory, String sensorName, long firstTimeOutOfRange, int noOfOutRange, int minValue, int maxValue, int currentValue) {
        this.equipmentName = equipmentName;
        this.locationName = locationName;
        this.equipmentCategory = equipmentCategory;
        this.sensorName = sensorName;
        this.firstTimeOutOfRange = firstTimeOutOfRange;
        this.noOfOutRange = noOfOutRange;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.message = "";
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getEquipmentCategory() {
        return equipmentCategory;
    }

    public void setEquipmentCategory(String equipmentCategory) {
        this.equipmentCategory = equipmentCategory;
    }

    public String getSensorName() {
        return sensorName;
    }

    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    public long getFirstTimeOutOfRange() {
        return firstTimeOutOfRange;
    }

    public void setFirstTimeOutOfRange(long firstTimeOutOfRange) {
        this.firstTimeOutOfRange = firstTimeOutOfRange;
    }

    public int getNoOfOutRange() {
        return noOfOutRange;
    }

    public void setNoOfOutRange(int noOfOutRange) {
        this.noOfOutRange = noOfOutRange;
    }

    public int getMinValue() {
        return minValue;
    }

    public void setMinValue(int minValue) {
        this.minValue = minValue;
    }

    public int getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
    }

    public int getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(int currentValue) {
        this.currentValue = currentValue;
    }

}
