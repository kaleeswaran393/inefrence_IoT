package com.senslytics.datadendron.utils;


import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	private static ObjectMapper mapper = new ObjectMapper();

	public static String toJson(Object o) throws JsonGenerationException,
			JsonMappingException, IOException {
		return mapper.writeValueAsString(o);
	}

	public static <T> T toObject(String json, Class<T> type) throws JsonGenerationException,
			JsonMappingException, IOException {
		return mapper.readValue(json, type);
	}

	public static <T> T toObject(String json, TypeReference type)
			throws JsonGenerationException, JsonMappingException, IOException {
		return mapper.readValue(json,type);
	}
}
