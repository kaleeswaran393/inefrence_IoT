package com.senslytics.webservice.webservices;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONObject;

import com.senslytics.webservice.model.database.EquipmentCategory;
import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.model.database.EquipmentValueDetail;
import com.senslytics.webservice.model.database.GeographyLocation;
import com.senslytics.webservice.model.database.Sensor;
import com.senslytics.webservice.model.restparms.CategoryResponse;
import com.senslytics.webservice.model.restparms.EquipmentNotificationResponse;
import com.senslytics.webservice.model.restparms.EquipmentStatusResponse;
import com.senslytics.webservice.model.restparms.LocationResponse;
import com.senslytics.webservice.model.restparms.NotificationResponse;
import com.senslytics.webservice.model.utils.Constant;
import com.senslytics.webservice.notification.NotificationBean;
import com.senslytics.webservice.notification.ParameterDetail;

@Path("/geography")
public class GeographyLocationService extends Constant {

    @Path("/locationlist")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public LocationResponse locationList(JSONObject req) {
        Set<GeographyLocation> response2 = null;
        LocationResponse res = new LocationResponse();
        List<GeographyLocation> response = new ArrayList<GeographyLocation>();
        try {
            response = new DbConn().getMember(req.getString("userName"));
            response2 = new HashSet<GeographyLocation>(response);
            res.setLocation(response2);
            res.setStatus(SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    @Path("/equipmentcategory")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public CategoryResponse catagories(JSONObject req) {

        CategoryResponse res = new CategoryResponse();
        List<EquipmentCategory> response = new ArrayList<EquipmentCategory>();
        try {
            response = new DbConn().getEquipment(req.getString("userName"), req.getLong("locationId"));
            res.setCategory(response);
            res.setStatus(SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    @Path("/mynotification")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public NotificationResponse equipments(JSONObject req) {
        NotificationResponse res = new NotificationResponse();
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        try {
            notificationList = new NotificationService().getMyNotificationList(req.getString("userId"));
            res.setNotification(notificationList);
            res.setStatus(SUCCESS);
        } catch (Exception e) {
            res.setStatus(FAILURE);
            e.printStackTrace();
        }
        return res;
    }

    @Path("/notification")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public EquipmentNotificationResponse notification(JSONObject req) {
        EquipmentNotificationResponse res = new EquipmentNotificationResponse();
        List<EquipmentCategory> notificationList = new ArrayList<EquipmentCategory>();
        try {
            notificationList = new NotificationService().getNotificationList(req.getString("userId"));
            res.setNotification(notificationList);
            res.setStatus(SUCCESS);
        } catch (Exception e) {
            res.setStatus(FAILURE);
            e.printStackTrace();
        }
        return res;
    }

    @Path("/equipmentdetail")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public EquipmentStatusResponse equipmentDetail(JSONObject req) {
        EquipmentStatusResponse res = new EquipmentStatusResponse();
        List<Sensor> sensor = new ArrayList<Sensor>();
        EquipmentValueDetail prevValue = new EquipmentValueDetail();
        try {
            sensor = new DbConn().getSensors(req.getString("EquipmentId"));
            String toDate = req.getString("currenttime");
            int hours = req.getInt("hours");
            TimeZone fromTz = TimeZone.getTimeZone(req.get("timezone").toString());
            for (int i = 0; i < sensor.size(); i++) {
                prevValue = new ParameterDetail().readinTimeRange(sensor.get(i).getParameter().getId(), toDate, fromTz, hours);
                sensor.get(i).setPrevValue(prevValue);
            }
            res.setSensor(sensor);
            res.setStatus(SUCCESS);
        } catch (Exception e) {
            res.setStatus(FAILURE);
            e.printStackTrace();
        }
        return res;
    }

}
