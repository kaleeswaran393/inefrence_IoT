/**
 *
 */
package com.senslytics.webservice.model.database;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Prabakaran
 *
 */
public class Parameters {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private String id;
    @Column(name = "parameter")
    private String parameter;
    @Column(name = "sensor_id")
    private String sensorId;
    @Column(name = "current_val")
    private Long currentValue;

    @Column(name = "max_val")
    private Long maximumValue;
    @Column(name = "min_val")
    private Long minimumValue;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getSensorId() {
        return sensorId;
    }

    public void setSensorId(String sensorId) {
        this.sensorId = sensorId;
    }

    /**
     * @return the currentValue
     */
    public Long getCurrentValue() {
        return currentValue;
    }

    /**
     * @param currentValue the currentValue to set
     */
    public void setCurrentValue(Long currentValue) {
        this.currentValue = currentValue;
    }

    /**
     * @return the maximumValue
     */
    public Long getMaximumValue() {
        return maximumValue;
    }

    /**
     * @param maximumValue the maximumValue to set
     */
    public void setMaximumValue(Long maximumValue) {
        this.maximumValue = maximumValue;
    }

    /**
     * @return the minimumValue
     */
    public Long getMinimumValue() {
        return minimumValue;
    }

    /**
     * @param minimumValue the minimumValue to set
     */
    public void setMinimumValue(Long minimumValue) {
        this.minimumValue = minimumValue;
    }

}
