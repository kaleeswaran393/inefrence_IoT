package com.senslytics.webservice.notification;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.model.database.EquipmentCategory;

import oracle.kv.Consistency;
import oracle.kv.Direction;
import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;
import oracle.kv.table.TableIteratorOptions;

public class PredictionReader {

    static Logger log = Logger.getLogger(PredictionReader.class.getName());

    NOSQLConnectionFactory ncf = new NOSQLConnectionFactory();
    private KVStore store = ncf.getKVStore();
    DateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public NotificationBean readinTimeRange(NotificationBean bean, long toDate, String tagId) {
        long fromDate = getBackHour(toDate);
        int minValue = bean.getMinValue();
        int maxValue = bean.getMaxValue();
        int outOfRange = 0;
        String message = null;
        long firstDate = 0;
        TableAPI tableAPI = ncf.getTableAPI(store);

        Table tableChild = tableAPI.getTable("tag.sensor_reading");//GSA_VE11156Y
        PrimaryKey key = tableChild.createPrimaryKey();
        key.put("tag_name", tagId);

        FieldRange range = tableChild.createFieldRange("tag_time");
        range.setStart(fromDate, true);
        range.setEnd(toDate, true);
        MultiRowOptions mro = range.createMultiRowOptions();
        TableIterator<Row> iter = tableAPI.tableIterator(key, mro, null);
        System.out.println("Getting tag value");
        while (iter.hasNext()) {
            Row row = iter.next();
            if ((Double.valueOf(row.get("tag_value").asString().get()) < minValue) || ((Double.valueOf(row.get("tag_value").asString().get()) > maxValue))) {
                if (outOfRange == 0) {
                    firstDate = row.get("tag_time").asLong().get();
                    bean.setFirstTimeOutOfRange(firstDate);
                }
                outOfRange += 1;
            }
        }
        bean.setNoOfOutRange(outOfRange);
        Date date = new Date(bean.getFirstTimeOutOfRange());
        //DateFormat formatter = new SimpleDateFormat("HH:mm:ss:SSS");
        String dateFormatted = formater.format(date);
        if (bean.getFirstTimeOutOfRange() != 0) {
            message = bean.getEquipmentCategory() + " " + bean.getEquipmentName() + " " + bean.getSensorName() + " in " + bean.getLocationName()
                        + " Location has been going out of range infrequently. In last 1 hour it has been gone " + outOfRange
                        + " times out of range.First time it went out of range at " + dateFormatted;
        }
        bean.setMessage(message);
        //bean.setFirstTimeOutOfRange(dateFormatted);
        return bean;
    }

    public NotificationBean readRresult(String tagId, DbConn db) {
        NotificationBean bean = null;
        TableAPI tableAPI = ncf.getTableAPI(store);
        Table tableChild = tableAPI.getTable("tag.failure_prediction");
        PrimaryKey key = tableChild.createPrimaryKey();
        key.put("tag_name", tagId);
        key.put("failure_predicted", 1);
        Row k = null;
        TableIterator<Row> i = tableAPI.tableIterator(key, null, new TableIteratorOptions(Direction.REVERSE, Consistency.NONE_REQUIRED, 0, null));
        while (i.hasNext()) {
            k = i.next();
            break;
        }
        if (k != null) {
            bean = readinTimeRange(db.getMetaData(tagId), k.get("tw_end_date").asLong().get(), tagId);
        }

        return bean;
    }

    public List<EquipmentCategory> getNotificationforEquipment(String userId) {
        List<EquipmentCategory> arr = new ArrayList<EquipmentCategory>();
        NotificationBean bean = new NotificationBean(null, null, null, null, 0, 0, 0, 0, 0);
        try {
            DbConn db = new DbConn();
            arr = db.getEquipment(userId);
            for (int i = 0; i < arr.size(); i++) {
                int noequipment = arr.get(i).getEquipments().size();
                for (int j = 0; j < noequipment; j++) {
                    int nosensor = arr.get(i).getEquipments().get(j).getSensor().size();
                    arr.get(i).getEquipments().get(j).getEquipmentLocationId();
                    for (int k = 0; k < nosensor; k++) {
                        bean = readRresult(arr.get(i).getEquipments().get(j).getSensor().get(k).getParameter().getId(), db);
                        if (bean != null) {
                            arr.get(i).getEquipments().get(j).setEquipmentLocationId(bean.getLocationName());
                            arr.get(i).getEquipments().get(j).setEquipmentDescription(bean.getMessage());
                        }
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return arr;
    }

    public List<NotificationBean> getNotificationList(String userId) {
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        List<String> sensor = new ArrayList<String>();
        try {
            DbConn con = new DbConn();
            sensor = con.getTag(userId);
            for (int i = 0; i < sensor.size(); i++) {
                notificationList.add(readRresult(sensor.get(i), con));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notificationList;
    }

    public long getBackHour(long date) {
        return date - 3600000;
    }

}
