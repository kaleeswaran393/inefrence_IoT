package com.senslytics.webservice.model.restparms;

import java.util.ArrayList;
import java.util.List;
import com.senslytics.webservice.model.utils.ResponseModel;
import com.senslytics.webservice.notification.NotificationBean;

public class NotificationResponse extends ResponseModel {

    List<NotificationBean> notification = new ArrayList<NotificationBean>();

    public List<NotificationBean> getNotification() {
        return notification;
    }

    public void setNotification(List<NotificationBean> category) {
        this.notification = category;
    }

}
