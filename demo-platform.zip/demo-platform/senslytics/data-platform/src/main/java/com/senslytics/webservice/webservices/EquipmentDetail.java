package com.senslytics.webservice.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONObject;

import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.model.database.Sensor;
import com.senslytics.webservice.model.restparms.EquipmentDetailResponse;
import com.senslytics.webservice.model.utils.Constant;

@Path("/equipment")

public class EquipmentDetail extends Constant {

    @Path("/equipmentdetail")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public EquipmentDetailResponse equipments(JSONObject req) {
        EquipmentDetailResponse res = new EquipmentDetailResponse();
        List<Sensor> response = new ArrayList<Sensor>();
        try {
            response = new DbConn().getSensors(req.getString("equipmentId"));
            res.setSensor(response);
            res.setEquipmentLocationId(req.getString("locationId"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }
}
