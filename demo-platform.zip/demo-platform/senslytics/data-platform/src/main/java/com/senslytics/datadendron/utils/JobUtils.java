package com.senslytics.datadendron.utils;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobKey;
import org.quartz.impl.JobDetailImpl;

public class JobUtils extends JobDetailImpl {

    public JobUtils(Class<? extends Job> jobClass, String jobName) {
        setName(jobName);
        setJobClass(jobClass);
    }

}
