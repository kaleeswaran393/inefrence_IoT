package com.senslytics.webservice.model.database;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.senslytics.webservice.notification.NotificationBean;

public class DbConn {

    Connection con;
    Statement st;
    ResultSet rs;

    public DbConn() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(
                        "jdbc:mysql://sensusdev.senslytics.com:3306/sensuite", "root", "password");
            st = (Statement) con.createStatement();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<GeographyLocation> getMember(String userName) {
        List<GeographyLocation> locationList = new ArrayList<GeographyLocation>();
        try {
            String query = "select * from company where CompanyID = (select CompanyID from "
                        + "users where UserName = '" + userName + "')";
            rs = st.executeQuery(query);
            while (rs.next()) {
                GeographyLocation location = new GeographyLocation();
                location.setLocationId(rs.getLong("LocationID"));
                location.setCity(rs.getString("City"));
                location.setState(rs.getString("State"));
                location.setCountry(rs.getString("Country"));
                locationList.add(location);
            }
        } catch (SQLException e) {
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return locationList;
    }

    public List<EquipmentCategory> getEquipment(String userName, Long locationId) {
        List<EquipmentCategory> categoryList = new ArrayList<EquipmentCategory>();
        try {
            String query = "select * from company_assets where CompanyID = (select CompanyID from "
                        + "users where UserName = '" + userName + "') and LocationId = " + locationId;
            rs = st.executeQuery(query);
            while (rs.next()) {
                EquipmentCategory equipment = new EquipmentCategory();
                equipment.setEquipmentCategoryId(rs.getString("EquipmentCategoryID"));
                equipment.setEquipmentCategory(rs.getString("EquipmentCategory"));
                categoryList.add(equipment);
            }
            for (int i = 0; i < categoryList.size(); i++) {
                List<EquipmentList> equipments = new ArrayList<EquipmentList>();
                equipments = getEquipments(categoryList.get(i).getEquipmentCategoryId());
                categoryList.get(i).setEquipments(equipments);
            }

        } catch (SQLException e) {
            System.out.println(e);
        }

        return categoryList;
    }

    public List<EquipmentCategory> getEquipment(String userName) {
        List<EquipmentCategory> categoryList = new ArrayList<EquipmentCategory>();
        try {
            String query = "select * from company_assets where CompanyID = (select CompanyID from "
                        + "users where UserName = '" + userName + "')";
            rs = st.executeQuery(query);
            while (rs.next()) {
                EquipmentCategory equipment = new EquipmentCategory();
                equipment.setEquipmentCategoryId(rs.getString("EquipmentCategoryID"));
                equipment.setEquipmentCategory(rs.getString("EquipmentCategory"));
                categoryList.add(equipment);
            }
            for (int i = 0; i < categoryList.size(); i++) {
                List<EquipmentList> equipments = new ArrayList<EquipmentList>();
                equipments = getEquipments(categoryList.get(i).getEquipmentCategoryId());
                categoryList.get(i).setEquipments(equipments);
            }

        } catch (SQLException e) {
            System.out.println(e);
        }

        return categoryList;
    }

    public List<EquipmentList> getEquipments(String equipmentCat) {
        List<EquipmentList> equipments = new ArrayList<EquipmentList>();
        try {
            String query = "select * from equipments where EquipmentCategoryID = '" + equipmentCat + "'";
            ResultSet rs1 = st.executeQuery(query);
            while (rs1.next()) {
                EquipmentList equipment = new EquipmentList();
                equipment.setEquipmentCategoryId(equipmentCat);
                equipment.setEquipementName(rs1.getString("Equipment_Name"));
                equipment.setEquipmentListId(rs1.getString("Equipment_List_ID"));
                equipments.add(equipment);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        for (int i = 0; i < equipments.size(); i++) {
            List<Sensor> sensor = new ArrayList<Sensor>();
            sensor = getSensors(equipments.get(i).getEquipmentListId());
            equipments.get(i).setSensor(sensor);
        }
        return equipments;
    }

    public List<Sensor> getSensors(String equipmentId) {
        List<Sensor> sensors = new ArrayList<Sensor>();
        try {
            String query = "select * from sensors s, tag t where s.Equipment_ID = '" + equipmentId + "' and t.Sensor_ID = s.Sensor_ID";
            ResultSet rs2 = st.executeQuery(query);
            while (rs2.next()) {
                Sensor sensor = new Sensor();
                sensor.setEquipmentId(equipmentId);
                sensor.setId(rs2.getString("Sensor_ID"));
                sensor.setSensore(rs2.getString("Sensor_Name"));
                Parameters parameter = new Parameters();
                parameter.setCurrentValue(rs2.getLong("Current_Value"));
                parameter.setId(rs2.getString("Tag_ID"));
                parameter.setMaximumValue(rs2.getLong("Max_Value"));
                parameter.setMinimumValue(rs2.getLong("Min_Value"));
                parameter.setParameter(rs2.getString("Tag_Name"));
                parameter.setSensorId(rs2.getString("Sensor_ID"));
                sensor.setParameter(parameter);
                sensors.add(sensor);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return sensors;
    }

    public NotificationBean getMetaData(String tagId) {
        String location, equipment, equipmentCaterogy, tagName;
        int minValue, maxValue;
        NotificationBean bean = null;
        try {
            String query = "select * from company c,company_assets a ,equipments e, sensors s, tag t  where c.CompanyID=(select CompanyID from company_assets a ,equipments e, sensors s, tag t  where a.EquipmentCategoryID=e.EquipmentCategoryID and e.Equipment_List_ID=s.Equipment_ID and s.Sensor_ID=t.Sensor_ID and t.Tag_ID='" + tagId + "') and a.EquipmentCategoryID=e.EquipmentCategoryID and e.Equipment_List_ID=s.Equipment_ID and s.Sensor_ID=t.Sensor_ID and t.Tag_ID='" + tagId + "'";
            //System.out.println(query);
            rs = st.executeQuery(query);
            if (rs.next()) {
                location = rs.getString("Country");
                equipmentCaterogy = rs.getString("EquipmentCategory");
                equipment = rs.getString("Equipment_Name");
                tagName = rs.getString("Tag_Name");
                minValue = rs.getInt("Min_Value");
                maxValue = rs.getInt("Max_Value");
                bean = new NotificationBean(equipment, location, equipmentCaterogy,
                            tagName, 0, 0, minValue, maxValue, 0);
            }

        } catch (SQLException e) {
            System.out.println(e);
        }/*finally{
         if(con!=null){
         try {
         rs.close();
         st.close();
         con.close();
         } catch (SQLException e) {
         e.printStackTrace();
         }
                
         }
                
         }*/

        return bean;
    }

    public List<EquipmentCategory> getEquipmentDetail(String userName) {
        List<EquipmentCategory> categoryList = new ArrayList<EquipmentCategory>();
        try {
            String query = "select * from company c, company_assets a, equipments e, sensors s, tag t where "
                        + "a.EquipmentCategoryID = e.EquipmentCategoryID and e.Equipment_List_ID = s.Equipment_ID "
                        + "and s.Sensor_ID = t.Sensor_ID and a.CompanyID = (select CompanyID from Users where UserName = '" + userName + "')";
            rs = st.executeQuery(query);
            while (rs.next()) {
                EquipmentCategory equipment = new EquipmentCategory();
                equipment.setEquipmentCategoryId(rs.getString("EquipmentCategoryID"));
                equipment.setEquipmentCategory(rs.getString("EquipmentCategory"));
                List<EquipmentList> equipments = new ArrayList<EquipmentList>();
                EquipmentList equipmentList = new EquipmentList();
                equipmentList.setEquipmentCategoryId(rs.getString("EquipmentCategory"));
                equipmentList.setEquipementName(rs.getString("Equipment_Name"));
                equipmentList.setEquipmentListId(rs.getString("Equipment_List_ID"));
                equipmentList.setEquipmentLocationId(rs.getString("Country"));
                equipments.add(equipmentList);
                equipment.setEquipments(equipments);
                categoryList.add(equipment);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return categoryList;
    }

    public List<String> getTag(String userName) {
        List<String> arr = new ArrayList<String>();
        String val;
        try {
            String query = "select * from users u,company_assets c, equipments e, sensors s, tag t where u.CompanyId = c.CompanyID and u.UserName = '" + userName + "' and c.EquipmentCategoryID = e.EquipmentCategoryID and s.Equipment_ID = e.Equipment_List_ID and s.Sensor_ID = t.Sensor_ID";
            ResultSet rs1 = st.executeQuery(query);

            while (rs1.next()) {
                val = rs1.getString("Tag_ID");
                arr.add(val);
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        return arr;
    }
}
