package com.senslytics.webservice.notification;

import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.senslytics.webservice.model.database.DbConn;
import com.senslytics.webservice.model.database.EquipmentCategory;

import oracle.kv.Consistency;
import oracle.kv.Direction;
import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import oracle.kv.table.TableIterator;
import oracle.kv.table.TableIteratorOptions;

public class PredictionsReader {

    static Logger log = Logger.getLogger(PredictionReader.class.getName());

    NOSQLConnectionFactory ncf = new NOSQLConnectionFactory();
    private KVStore store = ncf.getKVStore();

    Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public NotificationBean readinTimeRange(NotificationBean bean, int toDate, String tagId) {
        int fromDate = getBackHour(toDate);
        int minValue = bean.getMinValue();
        int maxValue = bean.getMaxValue();
        int outOfRange = 0;
        String message = null;
        //String firstDate = null;
        TableAPI tableAPI = ncf.getTableAPI(store);
        /*Changes start*/
        Table tableChild = tableAPI.getTable("tag.sensor_reading");//GSA_VE11156Y
        /*Changes end */
        PrimaryKey key = tableChild.createPrimaryKey();
        //key.put("tag_name", tagId);
        FieldRange range = tableChild.createFieldRange("tag_time");
        range.setStart(fromDate, true);
        range.setEnd(toDate, true);
        MultiRowOptions mro = range.createMultiRowOptions();
        TableIterator<Row> iter = tableAPI.tableIterator(key, mro, null);
        while (iter.hasNext()) {
            Row row = iter.next();
            if ((Double.valueOf(row.get("tag_value").asString().get()) < minValue) || ((Double.valueOf(row.get("tag_value").asString().get()) > maxValue))) {
                if (outOfRange == 0) {
                    //firstDate=row.get("tag_time").asString().get();
                    //bean.setFirstTimeOutOfRange(firstDate);
                }
                outOfRange += 1;
            }
        }
        bean.setNoOfOutRange(outOfRange);
        if (bean.getFirstTimeOutOfRange() != 0) {
            message = bean.getEquipmentCategory() + " " + bean.getEquipmentName() + bean.getSensorName() + " in " + bean.getLocationName()
                        + " Location has been going out of range infrequently. In last 1 hour it has been gone " + outOfRange
                        + " times out of range.First time it went out of range at " + bean.getFirstTimeOutOfRange();
        }
        bean.setMessage(message);
        return bean;
    }

    public NotificationBean readRresult(String tagId, DbConn con) {
        NotificationBean bean = null;
        //List<Row> rowList=null;

        TableAPI tableAPI = ncf.getTableAPI(store);

        //Table tableChild = tableAPI.getTable("tag_sensor.prediction_outcome");//r_predict.detail_taginfo
        Table tableChild = tableAPI.getTable("tag.prediction_failure");//new prediction table
        PrimaryKey key = tableChild.createPrimaryKey();
        key.put("tag_name", tagId);
        key.put("failure_prediction", 1);

        /*Iterator<KeyValueVersion> i =
         store.multiGetIterator(Direction.REVERSE, 0, key, null, null);
         while (i.hasNext()) {
         Key k = i.next().getKey();
         System.out.println(k.toString());
         break; // got the first row
         }*/
        Row k = null;
        TableIterator<Row> i = tableAPI.tableIterator(key, null, new TableIteratorOptions(Direction.REVERSE, Consistency.NONE_REQUIRED, 0, null));
        while (i.hasNext()) {
            k = i.next();
            System.out.println(k.toString());
            break; // got the first row
        }
        //rowList=tableAPI.multiGet(key, null, null);
        bean = readinTimeRange(con.getMetaData(tagId), k.get("tw_end_date").asInteger().get(), tagId);
        /*if(rowList!=null){
         for(Row row : rowList){
         if(row.get("failure_prediction").asInteger().get()==1){
         //try {
         //DbConn db=new DbConn();
         bean=readinTimeRange(con.getMetaData(tagId), row.get("tw_end_date").asInteger().get(), tagId);
         /*} catch (SQLException e) {
         e.printStackTrace();
         }
         }
         }
         }*/

        return bean;
    }

    public List<EquipmentCategory> getNotificationforEquipment(String userId) {
        List<EquipmentCategory> arr = new ArrayList<EquipmentCategory>();
        try {
            DbConn conn = new DbConn();
            arr = conn.getEquipment(userId);
            for (int i = 0; i < arr.size(); i++) {
                int noequipment = arr.get(i).getEquipments().size();
                for (int j = 0; j < noequipment; j++) {
                    int nosensor = arr.get(i).getEquipments().get(j).getSensor().size();
                    arr.get(i).getEquipments().get(j).getEquipmentLocationId();
                    for (int k = 0; k < nosensor; k++) {
                        NotificationBean bean = readRresult(arr.get(i).getEquipments().get(j).getSensor().get(k).getParameter().getId(), conn);
                        arr.get(i).getEquipments().get(j).setEquipmentLocationId(bean.getLocationName());
                        arr.get(i).getEquipments().get(j).setEquipmentDescription(bean.getMessage());
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return arr;
    }

    public List<NotificationBean> getNotificationList(String userId) {
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        List<String> sensor = new ArrayList<String>();
        try {
            DbConn con = new DbConn();
            sensor = con.getTag(userId);
            for (int i = 0; i < sensor.size(); i++) {
                notificationList.add(readRresult(sensor.get(i), con));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notificationList;
    }
    /* Main changes are in this function as now I am just subtracting no. of milli seconds in 1 hour*/

    public int getBackHour(int date) {

        /*SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
         Date date1 ;
         Calendar cal = Calendar.getInstance(); // creates calendar
         date1 = new Date(date);
         //date1 = formatter.parse(date);
         cal.setTime(date1); // sets calendar time/date
         cal.add(Calendar.HOUR_OF_DAY, -1); // adds one hour
         cal.getTime(); // returns new date object, one hour in the future
         */
        int fromdate = date - 3600000;
        return fromdate;// 1 hour = 60*60*1000 milli seconds
        //return date - 3600000;
    }

}
