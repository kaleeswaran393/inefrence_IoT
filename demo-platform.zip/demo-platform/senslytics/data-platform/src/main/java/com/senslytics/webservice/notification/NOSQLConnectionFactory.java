package com.senslytics.webservice.notification;

import java.util.logging.Logger;
import oracle.kv.KVStore;
import oracle.kv.KVStoreConfig;
import oracle.kv.KVStoreFactory;
import oracle.kv.table.TableAPI;

public class NOSQLConnectionFactory {

    static Logger log = Logger.getLogger(NOSQLConnectionFactory.class.getName());

    public KVStore getKVStore() {
        log.info("In NOSQLConnectionFactory getKVStore()");
        KVStore store = null;
        try {
            store = KVStoreFactory.getStore(new KVStoreConfig("kvstore", "bigdatalite.localdomain" + ":" + "5000"));
        } catch (Exception e) {
            System.out.println(e);
            log.info("NOSQLConnectionFactory unable creating store" + e.getMessage());
        }
        return store;
    }

    public TableAPI getTableAPI(KVStore kvstore) {
        log.info("In NOSQLConnectionFactory getTableAPI()");
        TableAPI table = null;
        try {
            table = kvstore.getTableAPI();
        } catch (Exception e) {
            System.out.println(e);
            log.info("NOSQLConnectionFactory unable creating TableAPI" + e.getMessage());
        }
        return table;
    }
}
