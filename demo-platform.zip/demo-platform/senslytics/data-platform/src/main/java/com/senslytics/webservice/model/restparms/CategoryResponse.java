/**
 *
 */
package com.senslytics.webservice.model.restparms;

import java.util.ArrayList;
import java.util.List;

import com.senslytics.webservice.model.database.EquipmentCategory;
import com.senslytics.webservice.model.utils.ResponseModel;

/**
 * @author Prabakaran
 *
 */
public class CategoryResponse extends ResponseModel {

    List<EquipmentCategory> category = new ArrayList<EquipmentCategory>();

    public List<EquipmentCategory> getCategory() {
        return category;
    }

    public void setCategory(List<EquipmentCategory> category) {
        this.category = category;
    }

}
