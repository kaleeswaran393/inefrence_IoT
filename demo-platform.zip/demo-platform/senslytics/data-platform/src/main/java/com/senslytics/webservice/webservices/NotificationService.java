package com.senslytics.webservice.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.codehaus.jettison.json.JSONException;
import com.senslytics.webservice.model.database.EquipmentCategory;
import com.senslytics.webservice.notification.NotificationBean;
import com.senslytics.webservice.notification.PredictionReader;

@Path("/notification")
public class NotificationService {

    /*@GET
     @Path("/mynotification")
     @Produces("application/json")
     public List<NotificationBean> getMyNotificationList(JSONObject req){
     List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
     PredictionReader predictionReader =new PredictionReader();
     try{
     notificationList=predictionReader.getNotificationList(req.getString("userId"));
     }catch(Exception e){
     e.printStackTrace();
     }
     return notificationList;	
     }*/
    @Path("/mynotification")
    @GET
    @Consumes("application/json")
    @Produces("application/json")
    public List<NotificationBean> getMyNotificationList(@QueryParam("userId") String userId) throws JSONException {
        List<NotificationBean> notificationList = new ArrayList<NotificationBean>();
        PredictionReader predictionReader = new PredictionReader();
        try {
            notificationList = predictionReader.getNotificationList(userId);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return notificationList;
    }

    @GET
    @Path("/getnotification")
    @Produces("application/json")
    public List<EquipmentCategory> getNotificationList(String userId) {
        List<EquipmentCategory> notificationList = new ArrayList<EquipmentCategory>();
        PredictionReader predictionReader = new PredictionReader();
        try {
            notificationList = predictionReader.getNotificationforEquipment(userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notificationList;
    }

}
