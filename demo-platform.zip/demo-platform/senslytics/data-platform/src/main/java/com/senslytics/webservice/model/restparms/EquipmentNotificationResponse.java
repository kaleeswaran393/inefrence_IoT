package com.senslytics.webservice.model.restparms;

import java.util.ArrayList;
import java.util.List;

import com.senslytics.webservice.model.database.EquipmentCategory;
import com.senslytics.webservice.model.utils.ResponseModel;

public class EquipmentNotificationResponse extends ResponseModel {

    List<EquipmentCategory> notification = new ArrayList<EquipmentCategory>();

    public List<EquipmentCategory> getNotification() {
        return notification;
    }

    public void setNotification(List<EquipmentCategory> category) {
        this.notification = category;
    }

}
