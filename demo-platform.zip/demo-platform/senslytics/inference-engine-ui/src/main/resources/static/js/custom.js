/** Load Tag Names in the drop down * */

var entityListData = '';

$(document).ready(function() {
    $(document).ajaxStart(function() {
        $("#loader").css("display", "block");
    });
    $(document).ajaxComplete(function() {
        $("#loader").css("display", "none");
    });

    $.getJSON(URL_GET_ALL_TAG, function(data) {
        entityListData = data.tagEntityList;

        var options = '';
        var selectBoxObj = document.getElementById("sensorListSelectBox");

        // RESET VALUES
        $("input[type=text]").val('');

        $.each(data.tagEntityList, function(key, val) {
            var option = document.createElement("option");
            option.text = val.sensorID;
            option.value = val.sensorID + '||' + val.tagName;
            selectBoxObj.add(option, selectBoxObj[0]);

        });
    }).done(function() {
    }).fail(function() {
    }).always(function() {
    });

});

var tagName = '';
$("#sensorListSelectBox").change(function() {
    $("input[type=text]").attr("disabled", "disabled");
    tagName = this.value.split("||");


    // RESET VALUES
    $('#tagListSelectBox')
            .empty()
            .append('<option>Select the Tag</option>');
    $("#validationMsg").html("");

var tagSelectBoxObj = document.getElementById("tagListSelectBox");
        $.each(entityListData, function(key, val) {
            if(val.sensorID===tagName[0]){
            var option = document.createElement("option");
            option.text = val.tagName;
            option.value = val.tagName;
            // option.selected = "selected";
            tagSelectBoxObj.add(option, tagSelectBoxObj[1]);
        }
    });


   // var tagSelectBoxObj = document.getElementById("tagListSelectBox");
   // var option = document.createElement("option");
   // option.text = tagName[1];
   // option.selected = "selected";        
   // tagSelectBoxObj.add(option, tagSelectBoxObj[1]);

    $.getJSON(URL_FIND_BY_TAG_NAME + "?tagID=" + tagName[1] + "&sensorID=" + tagName[0], function(data) {
        $("#threshold").val(data.tagEntity.minimumThreshold);
        $("#max_threshold").val(data.tagEntity.maximumThreshold);
        $("#count").val(data.tagEntity.counter);
        $("#windowlength").val(data.tagEntity.windowLength);

    }).done(function() {
        // alert("second success");
    }).fail(function() {
        // alert("error");
    }).always(function() {
        // alert("complete");
    });
});

$("#tagListSelectBox").change(function() {   
    $.getJSON(URL_FIND_BY_TAG_NAME + "?tagID=" + $("#tagListSelectBox").val() + "&sensorID=" + tagName[0], function(data) {
        $("#threshold").val(data.tagEntity.minimumThreshold);
        $("#max_threshold").val(data.tagEntity.maximumThreshold);
        $("#count").val(data.tagEntity.counter);
        $("#windowlength").val(data.tagEntity.windowLength);

    }).done(function() {
        // alert("second success");
    }).fail(function() {
        // alert("error");
    }).always(function() {
        // alert("complete");
    });
});




/** Edit Button * */
$("#editButton").button();

$("#editButton").click(function() {
    $("input[type=text]").removeAttr("disabled");
});

/** Save Button * */
$("#saveButton").button({
    disabled: true
});

$("#saveButton").click(
        function() {
            var jsonData = '{"tagID": "' + tagName[1] + '", "windowLength" : "'
                    + $("#windowlength").val()
                    + '", "sensorID" : "'
                    + tagName[0]
                    + '", "counter" : "'
                    + $("#count").val()
                    + '", "minimumThreshold" : "'
                    + $("#threshold").val()
                    + '", "maximumThreshold" : "'
                    + $("#max_threshold").val()
                    + '"}'
            $.ajax({
                type: "POST",
                url: URL_ADD_TAG,
                contentType: 'application/json',
                data: jsonData,
                success: function(data) {
                    $("#validationMsg").html("<div class=\"success_msg\">Success!</div>");
                },
                failure: function(data) {
                    $("#validationMsg").html("<div class=\"fail_msg\">Transaction Failed. Try Again !</div>");
                }
            });
        });

/** Display Text Read only * */
$("input[type=text]").click(function() {
    $("#saveButton").button({
        disabled: false
    });
});

$("#tagListSelectBox").loader({
    defaults: true
});