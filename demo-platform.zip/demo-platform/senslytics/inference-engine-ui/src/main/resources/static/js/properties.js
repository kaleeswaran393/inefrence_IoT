var URL_GET_ALL_TAG = "http://localhost:9090/RuleConfiguration/selectAllTag";
var URL_FIND_BY_TAG_NAME = "http://localhost:9090/RuleConfiguration/findConfigurationByTagName";
var URL_ADD_TAG = "http://localhost:9090/RuleConfiguration/insert";
//URL_GET_ALL_TAG = "js/selectAllTag.json";
//URL_FIND_BY_TAG_NAME = "js/findConfigurationByTagName.json";
