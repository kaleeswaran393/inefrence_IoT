

package com.senselytics.inference.ui.controller;


import com.senselytics.inference.ui.dao.RuleConfigurationImplDAO;
import com.senselytics.inference.ui.dao.RuleConfigutaionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/RuleConfiguration")
public class RuleConfigurationController {
    
    private static final Logger logger = LoggerFactory.getLogger(RuleConfigurationImplDAO.class);
    
    @Autowired
    RuleConfigutaionService ruleConfigutaionService;
    
  

    @RequestMapping(value = "/insert", method = RequestMethod.POST,produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Request> insert(@RequestBody TagEntity tagEntity) {
        Request request = new Request();        
        ruleConfigutaionService.insert(tagEntity);
        logger.info("OUTPUT===>"+request);
        return new ResponseEntity<Request>(new Request(), HttpStatus.OK);
    }
    
    @RequestMapping(value = "/selectAllTag",method = RequestMethod.GET ,produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Request> selectAllTag() {       
        Request request = new Request();
        request.setTagEntityList(ruleConfigutaionService.selectAllTag());
        logger.info("OUTPUT===>"+request);
        return new ResponseEntity<Request>(request, HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/findConfigurationByTagName",method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Request> findConfigurationByTagName(@RequestParam(value="tagID", required=false) String tagID,
                @RequestParam(value="sensorID", required=false) String sensorID) {   
        logger.info("INPUT===>"+tagID);
        Request request = new Request();
        request.setTagEntity(ruleConfigutaionService.findConfigurationByTagName(tagID,sensorID));
        logger.info("OUTPUT===>"+request);
        return new ResponseEntity<Request>(request, HttpStatus.OK);
    }
    
}
