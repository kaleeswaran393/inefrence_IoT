
package com.senselytics.inference.ui.dao;


import com.senselytics.inference.ui.controller.TagEntity;
import com.senselytics.inference.ui.domain.jpa.entity.RuleConfiguration;
import java.util.List;


public interface RuleConfigutaionService {
    
   void insert(TagEntity tagEntity);
   List<TagEntity> selectAllTag();
   TagEntity findConfigurationByTagName(String tagID, String sensorID);
   
}
