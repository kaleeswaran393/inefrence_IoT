package com.senselytics.inference.ui.domain.jpa.repository;

import com.senselytics.inference.ui.domain.jpa.entity.Tag;
import com.senselytics.inference.ui.domain.jpa.entity.TagPK;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource(collectionResourceRel = "tag", path = "tag")
public interface TagRepository extends CrudRepository<Tag, TagPK>{
     
}
