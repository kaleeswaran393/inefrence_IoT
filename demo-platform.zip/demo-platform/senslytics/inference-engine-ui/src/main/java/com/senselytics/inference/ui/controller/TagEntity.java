package com.senselytics.inference.ui.controller;

import java.io.Serializable;

public class TagEntity implements Serializable {

	private Integer Id;
	private String tagID;
	private String tagName;
	private String sensorID;
	private Double currentValue;
	private Double minimumValue;
	private Double maximumValue;

	private String minimumThreshold;
	private String maximumThreshold;

	private String windowLength;
	private String counter;

	public TagEntity() {
	}

	/**
	 * @return the tagID
	 */
	public String getTagID() {
		return tagID;
	}

	/**
	 * @param tagID
	 *            the tagID to set
	 */
	public void setTagID(String tagID) {
		this.tagID = tagID;
	}

	/**
	 * @return the tagName
	 */
	public String getTagName() {
		return tagName;
	}

	/**
	 * @param tagName
	 *            the tagName to set
	 */
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	/**
	 * @return the sensorID
	 */
	public String getSensorID() {
		return sensorID;
	}

	/**
	 * @param sensorID
	 *            the sensorID to set
	 */
	public void setSensorID(String sensorID) {
		this.sensorID = sensorID;
	}

	/**
	 * @return the currentValue
	 */
	public Double getCurrentValue() {
		return currentValue;
	}

	/**
	 * @param currentValue
	 *            the currentValue to set
	 */
	public void setCurrentValue(Double currentValue) {
		this.currentValue = currentValue;
	}

	/**
	 * @return the minimumValue
	 */
	public Double getMinimumValue() {
		return minimumValue;
	}

	/**
	 * @param minimumValue
	 *            the minimumValue to set
	 */
	public void setMinimumValue(Double minimumValue) {
		this.minimumValue = minimumValue;
	}

	/**
	 * @return the maximumValue
	 */
	public Double getMaximumValue() {
		return maximumValue;
	}

	/**
	 * @param maximumValue
	 *            the maximumValue to set
	 */
	public void setMaximumValue(Double maximumValue) {
		this.maximumValue = maximumValue;
	}

	/**
	 * @return the windowLength
	 */
	public String getWindowLength() {
		return windowLength;
	}

	/**
	 * @param windowLength
	 *            the windowLength to set
	 */
	public void setWindowLength(String windowLength) {
		this.windowLength = windowLength;
	}

	/**
	 * @return the counter
	 */
	public String getCounter() {
		return counter;
	}

	/**
	 * @param counter
	 *            the counter to set
	 */
	public void setCounter(String counter) {
		this.counter = counter;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer Id) {
		this.Id = Id;
	}

	public String getMinimumThreshold() {
		return minimumThreshold;
	}

	public void setMinimumThreshold(String minimumThreshold) {
		this.minimumThreshold = minimumThreshold;
	}

	public String getMaximumThreshold() {
		return maximumThreshold;
	}

	public void setMaximumThreshold(String maximumThreshold) {
		this.maximumThreshold = maximumThreshold;
	}

	@Override
	public String toString() {
		return "TagEntity [Id=" + Id + ", tagID=" + tagID + ", tagName="
				+ tagName + ", sensorID=" + sensorID + ", currentValue="
				+ currentValue + ", minimumValue=" + minimumValue
				+ ", maximumValue=" + maximumValue + ", minimumThreshold="
				+ minimumThreshold + ", maximumThreshold=" + maximumThreshold
				+ ", windowLength=" + windowLength + ", counter=" + counter
				+ "]";
	}

}
