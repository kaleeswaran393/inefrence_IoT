package com.senselytics.inference.ui.controller;

import java.util.List;

public class Request {

    /**
     * @return the tagEntity
     */
    public TagEntity getTagEntity() {
        return tagEntity;
    }

    /**
     * @param tagEntity the tagEntity to set
     */
    public void setTagEntity(TagEntity tagEntity) {
        this.tagEntity = tagEntity;
    }

    /**
     * @return the tagEntityList
     */
    public List<TagEntity> getTagEntityList() {
        return tagEntityList;
    }

    /**
     * @param tagEntityList the tagEntityList to set
     */
    public void setTagEntityList(List<TagEntity> tagEntityList) {
        this.tagEntityList = tagEntityList;
    }
    
    public enum Status {
        OK,
        ERROR
    }
    
    public Request(){}
    
    private TagEntity tagEntity;
    
    private List<TagEntity> tagEntityList;    
    
    private List<String> errores;
    
    private Status status = Status.OK;
    
    
    public List<String> getErrores() {
        return errores;
    }

    public void setErrores(List<String> errores) {
        this.errores = errores;
    }
   
       /**
     * @return the status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Request{" + "tagEntity=" + tagEntity + ", tagEntityList=" + tagEntityList + ", errores=" + errores + ", status=" + status + '}';
    }

    
    
    
}
