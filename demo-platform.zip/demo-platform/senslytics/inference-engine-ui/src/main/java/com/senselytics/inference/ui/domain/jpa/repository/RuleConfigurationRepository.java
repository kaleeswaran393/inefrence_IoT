

package com.senselytics.inference.ui.domain.jpa.repository;

import com.senselytics.inference.ui.domain.jpa.entity.RuleConfiguration;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource(collectionResourceRel = "rule_configuration", path = "rule_configuration")
public interface RuleConfigurationRepository extends JpaRepository<RuleConfiguration, Integer>{
    @Query("SELECT b FROM RuleConfiguration b WHERE b.tagName=?1 and sensorID=?2")
    List<RuleConfiguration> findConfigurationByTagName(String tagID,String sensorID); 
    
    @Query("SELECT b FROM RuleConfiguration b WHERE b.tagName=?1 and sensorID=?2 and b.key=?3")
    RuleConfiguration findConfigurationByTagNameAndKey(String tagID,String sensorID,String key); 
}
