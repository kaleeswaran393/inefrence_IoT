/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.senselytics.inference.ui.domain.jpa.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author e2esystem
 */
@Entity
@Table(name = "tag")
public class Tag implements Serializable {


    @EmbeddedId
    protected TagPK tagPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Tag_Name")
    private String tagName;
    @Column(name = "Current_Value")
    private Integer currentValue;
    @Column(name = "Max_Value")
    private Integer maxValue;
    @Column(name = "Min_Value")
    private Integer minValue;

    public Tag() {
    }

    public Tag(TagPK tagPK) {
        this.tagPK = tagPK;
    }

    public Tag(TagPK tagPK, String tagName) {
        this.tagPK = tagPK;
        this.tagName = tagName;
    }

    public Tag(String tagID, String sensorID) {
        this.tagPK = new TagPK(tagID, sensorID);
    }

    public TagPK getTagPK() {
        return tagPK;
    }

    public void setTagPK(TagPK tagPK) {
        this.tagPK = tagPK;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public Integer getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Integer currentValue) {
        this.currentValue = currentValue;
    }

    public Integer getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    public Integer getMinValue() {
        return minValue;
    }

    public void setMinValue(Integer minValue) {
        this.minValue = minValue;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tagPK != null ? tagPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tag)) {
            return false;
        }
        Tag other = (Tag) object;
        if ((this.tagPK == null && other.tagPK != null) || (this.tagPK != null && !this.tagPK.equals(other.tagPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Tag{" + "tagPK=" + tagPK + ", tagName=" + tagName + ", currentValue=" + currentValue + ", maxValue=" + maxValue + ", minValue=" + minValue + '}';
    }

}
