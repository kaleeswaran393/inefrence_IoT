package com.senselytics.inference.ui.dao;

import com.senselytics.inference.ui.domain.jpa.entity.RuleConfiguration;
import com.senselytics.inference.ui.domain.jpa.entity.Tag;
import com.senselytics.inference.ui.controller.TagEntity;
import com.senselytics.inference.ui.domain.jpa.repository.RuleConfigurationRepository;
import com.senselytics.inference.ui.domain.jpa.repository.TagRepository;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class RuleConfigurationImplDAO implements RuleConfigutaionService {

    private static final Logger logger = LoggerFactory.getLogger(RuleConfigurationImplDAO.class);

    @Autowired
    RuleConfigurationRepository ruleConfigurationRepository;

    @Autowired
    TagRepository tagRepository;

    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void insert(TagEntity tagEntity) {
        logger.info("tagEntity input===>" + tagEntity);
        RuleConfiguration ruleCounter = ruleConfigurationRepository.findConfigurationByTagNameAndKey(tagEntity.getTagID(),tagEntity.getSensorID(), "counter");
        ruleCounter = ruleCounter == null ? new RuleConfiguration() : ruleCounter;
        ruleCounter.setTagName(tagEntity.getTagID());
        ruleCounter.setKey("counter");
        ruleCounter.setValue(tagEntity.getCounter());
        ruleCounter.setSensorID(tagEntity.getSensorID());
        ruleConfigurationRepository.save(ruleCounter);

        RuleConfiguration windowLength = ruleConfigurationRepository.findConfigurationByTagNameAndKey(tagEntity.getTagID(),tagEntity.getSensorID(), "window_length");
        windowLength = windowLength == null ? new RuleConfiguration() : windowLength;
        windowLength.setTagName(tagEntity.getTagID());
        windowLength.setKey("window_length");
        windowLength.setValue(tagEntity.getWindowLength());
        windowLength.setSensorID(tagEntity.getSensorID());
        ruleConfigurationRepository.save(windowLength);

        RuleConfiguration minThreshold = ruleConfigurationRepository.findConfigurationByTagNameAndKey(tagEntity.getTagID(),tagEntity.getSensorID(), "min_threshold");
        minThreshold = minThreshold == null ? new RuleConfiguration() : minThreshold;
        minThreshold.setTagName(tagEntity.getTagID());
        minThreshold.setKey("min_threshold");
        minThreshold.setValue(tagEntity.getMinimumThreshold());
        minThreshold.setSensorID(tagEntity.getSensorID());
        ruleConfigurationRepository.save(minThreshold);

        RuleConfiguration maxThreshold = ruleConfigurationRepository.findConfigurationByTagNameAndKey(tagEntity.getTagID(),tagEntity.getSensorID(), "max_threshold");
        maxThreshold = maxThreshold == null ? new RuleConfiguration() : maxThreshold;
        maxThreshold.setTagName(tagEntity.getTagID());
        maxThreshold.setKey("max_threshold");
        maxThreshold.setValue(tagEntity.getMaximumThreshold());
        maxThreshold.setSensorID(tagEntity.getSensorID());
        ruleConfigurationRepository.save(maxThreshold);
    }

    @Override
    public List<TagEntity> selectAllTag() {
        TagEntity entity = null;
        List<TagEntity> tagList = new ArrayList<TagEntity>();
        Iterator<Tag> it = tagRepository.findAll().iterator();

        while (it.hasNext()) {
            Tag tag = it.next();
            entity = new TagEntity();
            entity.setTagID(tag.getTagPK().getTagID());
            entity.setSensorID(tag.getTagPK().getSensorID());
            entity.setCounter(String.valueOf(tag.getMaxValue()));
            entity.setTagName(tag.getTagName());
           // entity.setWindowLength(String.valueOf(tag.getMinValue()));
           // entity.setMaximumThreshold(String.valueOf(tag.getMaxValue()));
           // entity.setMinimumThreshold(String.valueOf(tag.getMinValue()));
            tagList.add(entity);
        }
        return tagList;
    }

    public TagEntity findConfigurationByTagName(String tagID,String sensorID) {
        logger.info("tagID input===>" + tagID);
        logger.info("sensorID ===>" + sensorID);
        List<RuleConfiguration> configList = ruleConfigurationRepository.findConfigurationByTagName(tagID,sensorID);
        TagEntity tagEntity = new TagEntity();
        for (RuleConfiguration config : configList) {
            tagEntity.setTagID(tagID);
            tagEntity.setTagName(sensorID);
            if (config.getKey().equals("window_length")) {
                tagEntity.setWindowLength(config.getValue());
            } else if (config.getKey().equals("counter")) {
                tagEntity.setCounter(config.getValue());
            } else if (config.getKey().equals("min_threshold")) {
                tagEntity.setMinimumThreshold(config.getValue());
            } else if (config.getKey().equals("max_threshold")) {
                tagEntity.setMaximumThreshold(config.getValue());
            }
        }
        return tagEntity;
    }

}
