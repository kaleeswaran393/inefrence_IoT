
import com.senselytics.inference.ui.controller.Request;
import com.senselytics.inference.ui.controller.TagEntity;
import com.senselytics.inference.ui.domain.jpa.entity.RuleConfiguration;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import static junit.framework.Assert.assertEquals;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RuleConfigurationControllerTest {

    public static String URL = "http://localhost:9090/RuleConfiguration";

    RestTemplate restTemplate = new RestTemplate();

   // @Test
    public void insertConfiguration() throws URISyntaxException {

        TagEntity config = new TagEntity();
        config.setTagID("GSA_CH_LT11153");
        config.setWindowLength("2");
        config.setCounter("20");
     
        
        URI uri = new URI(URL+"/insert");
        HttpEntity <TagEntity> entity = new HttpEntity <TagEntity>(config);
        ResponseEntity<Request> request = restTemplate.exchange(uri, HttpMethod.POST, entity, Request.class);
        System.out.println("==>"+request);
        assertEquals(Request.Status.OK, request.getBody().getStatus().OK);
    }
    
    @Test
    public void selectAllTag() throws URISyntaxException {        
        URI uri = new URI(URL+"/selectAllTag");
        ResponseEntity<Request> request = restTemplate.exchange(uri, HttpMethod.GET, null, Request.class);
        System.out.println("==>"+request);
        assertEquals(Request.Status.OK, request.getBody().getStatus().OK);
        
    }

  //  @Test
    public void findConfigurationByTagName() throws URISyntaxException {        
        URI uri = new URI(URL+"/findConfigurationByTagName?tagID=GSA_VE11156Y");
        ResponseEntity<Request> request = restTemplate.exchange(uri, HttpMethod.GET, null, Request.class);
        System.out.println("==>"+request);
        assertEquals(Request.Status.OK, request.getBody().getStatus().OK);
        
    }

}
