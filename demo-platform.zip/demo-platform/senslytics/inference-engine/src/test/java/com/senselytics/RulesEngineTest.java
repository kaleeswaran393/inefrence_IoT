package com.senselytics;

import com.senselytics.inference.mq.MessageReceiverHandler;
import com.senselytics.inference.vo.TagEvent;
import java.io.IOException;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class RulesEngineTest extends TestCase {

    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public RulesEngineTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() {
        return new TestSuite(RulesEngineTest.class);
    }

    public void testThreshhold() throws IOException, InterruptedException {
        MessageReceiverHandler handler = MessageReceiverHandler.getInstance();
        Integer counter = 600;
        TagEvent tagEntity = handler.receiveEvent("GSA_YE11152", 600, new Date());
        handler.receiveEvent("GSA_YE11152", counter++, new Date());
        handler.receiveEvent("GSA_YE11152", counter++, new Date());
        handler.receiveEvent("GSA_YE11152", counter++, new Date());
        handler.receiveEvent("GSA_YE11152", counter++, new Date());
        handler.receiveEvent("GSA_YE11152", counter++, new Date());
        Thread.currentThread().sleep(1000);
       // handler.receiveEvent("Keyphasor Speed (rpm)", counter++, new Date());
      //  handler.receiveEvent("Keyphasor Speed (rpm)", counter++, new Date());
      //  handler.receiveEvent("Keyphasor Speed (rpm)", counter++, new Date());
      //  handler.receiveEvent("Keyphasor Speed (rpm)", counter++, new Date());
       // Thread.currentThread().sleep(1000);
        // handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        //  handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
      //  Thread.currentThread().sleep(1000);
        // handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        // handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        // handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        //  handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        //  handler.receiveEvent("GSA_CH_LT11153", counter++, new Date());
        //  Thread.currentThread().sleep(7000);
        System.out.println(tagEntity.getStatus());
        handler.dispose();
        assertTrue(true);
    }

    /* public void testCounter() throws InterruptedException {
        
     MessageReceiverHandler handler =  MessageReceiverHandler.getInstance();
        
     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     Thread.currentThread().sleep(2000);
     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     //  Thread.currentThread().sleep(2000);
     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     Thread.currentThread().sleep(2000);

     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     handler.receiveEvent("GSA_CH_LT11153", 600D,new Date());

     Thread.currentThread().sleep(2000);
     // and then dispose the session
     assertTrue(true);
     } */
}
