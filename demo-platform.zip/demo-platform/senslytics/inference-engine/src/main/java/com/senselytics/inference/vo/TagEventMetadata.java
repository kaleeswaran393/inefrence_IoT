package com.senselytics.inference.vo;

import java.util.Date;

public class TagEventMetadata {
    
	private String tagName;

	private int count=0;
	
	public int getCount() {
		return count;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	public void setCount(int count){
		this.count += count;
		System.out.println(count);
	}
}
