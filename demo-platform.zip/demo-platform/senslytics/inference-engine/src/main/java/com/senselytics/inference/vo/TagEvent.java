package com.senselytics.inference.vo;

import java.util.Date;

public class TagEvent {

    private String tagName;
    private int tagValue;
    private Date tagTime;
    private Status status = Status.WITHIN_RANGE;

    private String windowLength;
    private String counter;

    private Integer maxThreshold;
    private Integer minThreshold;

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public int getTagValue() {
        return tagValue;
    }

    public void setTagValue(int tagValue) {
        this.tagValue = tagValue;
    }

    public Date getTagTime() {
        return tagTime;
    }

    public void setTagTime(Date tagTime) {
        this.tagTime = tagTime;
    }

    /**
     * @return the status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * @return the maxThreshold
     */
    public Integer getMaxThreshold() {
        return maxThreshold;
    }

    /**
     * @param maxThreshold the maxThreshold to set
     */
    public void setMaxThreshold(Integer maxThreshold) {
        this.maxThreshold = maxThreshold;
    }

    /**
     * @return the minThreshold
     */
    public Integer getMinThreshold() {
        return minThreshold;
    }

    /**
     * @param minThreshold the minThreshold to set
     */
    public void setMinThreshold(Integer minThreshold) {
        this.minThreshold = minThreshold;
    }

    /**
     * @return the windowLength
     */
    public String getWindowLength() {
        return windowLength;
    }

    /**
     * @param windowLength the windowLength to set
     */
    public void setWindowLength(String windowLength) {
        this.windowLength = windowLength;
    }

    /**
     * @return the counter
     */
    public String getCounter() {
        return counter;
    }

    /**
     * @param counter the counter to set
     */
    public void setCounter(String counter) {
        this.counter = counter;
    }

    @Override
    public String toString() {
        return "TagEvent{" + "tagName=" + tagName + ", tagValue=" + tagValue + ", tagTime=" + tagTime + ", status=" + status + ", windowLength=" + windowLength + ", counter=" + counter + ", maxThreshold=" + maxThreshold + ", minThreshold=" + minThreshold + '}';
    }

}
