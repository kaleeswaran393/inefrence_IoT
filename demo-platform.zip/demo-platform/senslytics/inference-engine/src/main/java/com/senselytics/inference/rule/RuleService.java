package com.senselytics.inference.rule;

import java.util.List;

public interface RuleService<T> {

    T applyRules(T item);

    List<T> applyRules(List<T> items);

    public void destroy();
}
