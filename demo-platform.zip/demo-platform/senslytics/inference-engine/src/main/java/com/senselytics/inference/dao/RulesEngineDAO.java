package com.senselytics.inference.dao;

import com.senselytics.inference.vo.TagEvent;
import com.senslytics.datadendron.dp.SQLConnectionFactory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;

public class RulesEngineDAO {

    static Logger log = Logger.getLogger(RulesEngineDAO.class.getName());

    public static Map<String, TagEvent> selectAllConfigDetails() {
        SQLConnectionFactory factory = new SQLConnectionFactory();
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        TagEvent tagDetail = null;
        Map<String, TagEvent> tagDetails = new HashMap<String, TagEvent>();
        Map<String, String> tagIdMap = selectAllTagDetails();
        try {
            con = factory.getDBConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from rule_configuration");
            while (rs.next()) {               
                String tagID = tagIdMap.get(rs.getString(1)+"-"+rs.getString(5));
                if (tagDetails.containsKey(tagID)) {
                    tagDetail = tagDetails.get(tagID);
                } else {
                    tagDetail = new TagEvent();
                    tagDetail.setTagName(tagID);
                    tagDetails.put(tagDetail.getTagName(), tagDetail);
                }
                if (rs.getString(2).equals("window_length")) {
                    tagDetail.setWindowLength(rs.getString(3));
                } else if (rs.getString(2).equals("counter")) {
                    tagDetail.setCounter(rs.getString(3));
                } else if (rs.getString(2).equals("min_threshold")) {
                    tagDetail.setMinThreshold(rs.getInt(3));
                } else if (rs.getString(2).equals("max_threshold")) {
                    tagDetail.setMaxThreshold(rs.getInt(3));
                }

            }
        } catch (SQLException ex) {
            log.error(ex.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
                if (st != null) {
                    st.close();
                }
                if (st != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }

        }
        log.info("============================"+tagDetails);
        return tagDetails;
    }
    
    
    public static Map<String, String> selectAllTagDetails() {
        SQLConnectionFactory factory = new SQLConnectionFactory();
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        TagEvent tagDetail = null;
        Map<String, String> tagDetails = new HashMap<String, String>();
        try {
            con = factory.getDBConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from tag");
            while (rs.next()) {
                    tagDetail = new TagEvent();
                    tagDetail.setTagName(rs.getString(1));                    
                    tagDetails.put(rs.getString(2)+"-"+rs.getString(3), rs.getString(1));
            }
        } catch (SQLException ex) {
            log.error(ex.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
                if (st != null) {
                    st.close();
                }
                if (st != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                log.error(ex.getMessage());
            }

        }
        log.info("TagID Details -----"+tagDetails);
        return tagDetails;
    }
    

}
