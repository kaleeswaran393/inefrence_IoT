

package com.senselytics.inference.vo;

 public enum Status {
        OUT_OF_RANGE_HIGH,
        OUT_OF_RANGE_LOW,
        OUT_OF_RANGE,
        WITHIN_RANGE,
        COUNTER_THRESHOLD_REACHED
    }
