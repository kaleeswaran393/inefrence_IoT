package com.senselytics.inference.mq;

import com.senselytics.inference.rule.RulesEngineCloudMode;
import com.senselytics.inference.rule.RulesEngineStreamMode;
import com.senselytics.inference.vo.TagEvent;
import java.util.Date;
import org.apache.log4j.Logger;


public class MessageReceiverHandler {
    
    private static final Logger logger = Logger.getLogger(MessageReceiverHandler.class);
    private static MessageReceiverHandler messageReceiverHandler = null;
    
   // RulesEngineCloudMode<TagEvent> threshold = new RulesEngineCloudMode<TagEvent>();
    RulesEngineStreamMode<TagEvent> counter = new RulesEngineStreamMode<TagEvent>();  
    
    public MessageReceiverHandler(){}
    
    public static MessageReceiverHandler getInstance(){
        if(messageReceiverHandler==null){
            messageReceiverHandler = new MessageReceiverHandler();
        }
        return messageReceiverHandler;
    }
    
    public TagEvent receiveEvent(String tagName, Integer tagValue, Date date) {
        TagEvent entity = new TagEvent();
        entity.setTagName(tagName);
        entity.setTagValue(tagValue);      
        entity.setTagTime(date);
      //  entity = threshold.applyRules(entity);     
        counter.applyRules(entity);        
        return entity;
    }
    
    public void dispose(){
      //  threshold.destroy();
        counter.destroy();
    }
       
    
}
