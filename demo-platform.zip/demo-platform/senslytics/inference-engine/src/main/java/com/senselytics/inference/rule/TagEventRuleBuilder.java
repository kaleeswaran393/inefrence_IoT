package com.senselytics.inference.rule;

import com.senselytics.inference.vo.TagEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.commons.configuration.PropertiesConfiguration;

import org.drools.template.ObjectDataCompiler;

public class TagEventRuleBuilder {

    public static Reader buildRuleFromTemplate(TagEvent tagEvent) {
        ObjectDataCompiler converter = new ObjectDataCompiler();
        InputStream templateStream = ClassLoader
                    .getSystemResourceAsStream("com/senselytics/inference/rule/counter/Template_CounterEvent.template");
        if (null == templateStream) {
            System.out.println("Null stream");
        }
        Collection<Map<String, String>> paramMaps = new ArrayList<Map<String, String>>();
        Map<String, String> param = new HashMap<String, String>();
        param.put("tagName",tagEvent.getTagName());
        param.put("counter", tagEvent.getCounter());
        param.put("timeout", "1"); //TODO hardcoded now as 1s // it may change in future tagEvent.getWindowLength()
        paramMaps.add(param);
        String drl = converter.compile(paramMaps, templateStream);
        Reader rdr = new StringReader(drl);
        return rdr;
    }
    

    public static Set<String> prepareSet(PropertiesConfiguration prop) {
        Set<String> set = new HashSet<String>();
        String[] tagNames = prop.getStringArray("tagNames");
        for (String str : tagNames) {
            set.add(str);
        }
        return set;
    }

}
