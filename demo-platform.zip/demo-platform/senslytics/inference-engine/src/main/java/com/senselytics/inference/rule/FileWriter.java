

package com.senselytics.inference.rule;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import org.apache.log4j.Logger;


public class FileWriter {
    private static final Logger logger = Logger.getLogger(FileWriter.class);
    public static void writer(String content) throws IOException{
        File file = new File("src/main/resources/notification.txt");
        logger.info(file.getAbsoluteFile());
        java.io.FileWriter fw = new java.io.FileWriter(file.getAbsoluteFile(),true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write("\n");
        bw.write(content);
        bw.flush();
        bw.close();
    }
}
