package com.senselytics.inference.rule;

import com.senselytics.inference.dao.RulesEngineDAO;
import com.senselytics.inference.vo.TagEvent;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class RulesEngineCloudMode<T> implements RuleService<T> {

    private static Logger log = Logger.getLogger(RulesEngineCloudMode.class.getName());

    private KieSession ksession;
    private KieContainer kContainer;

    public RulesEngineCloudMode() {
        init();
    }

    public T applyRules(T item) {
        ksession.insert(item);
        ksession.fireAllRules();
        return item;
    }

    public List<T> applyRules(List<T> items) {
        for (T item : items) {
            ksession.insert(item);
            ksession.fireAllRules();
        }
        return items;
    }

    private void init() {
        KieServices kieServices = KieServices.Factory.get();
        kContainer = kieServices.getKieClasspathContainer();
        KieBase kBase1 = kContainer.getKieBase("SenslyticsCloudModeRulesEngineKB");
        ksession = kContainer.newKieSession("SenslyticsRulesEngineKS");
        Map<String, TagEvent> map = RulesEngineDAO.selectAllConfigDetails();
        log.info("###############" + map.get("GSA_CH_LT11153"));
        ksession.setGlobal("map", map);
    }

    public void destroy() {
        ksession.dispose();
    }

}
