package com.senselytics.inference.rule;

import com.senselytics.inference.dao.RulesEngineDAO;
import com.senselytics.inference.vo.TagEvent;
import java.util.Collection;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.kie.api.KieBaseConfiguration;
import org.kie.api.conf.EventProcessingOption;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSessionConfiguration;
import org.kie.api.runtime.conf.ClockTypeOption;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.KnowledgeBaseFactory;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.definition.KnowledgePackage;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.runtime.StatefulKnowledgeSession;

public class RulesEngineStreamMode<T> implements RuleService<T> {

    private static Logger log = Logger.getLogger(RulesEngineStreamMode.class.getName());

    // private KieSession ksession;
    // private KieContainer kContainer;
    private StatefulKnowledgeSession ksession;

    public RulesEngineStreamMode() {
        init();
    }

    public T applyRules(T item) {
        ksession.insert(item);
        // ksession.fireAllRules();
        return item;
    }

    public List<T> applyRules(List<T> items) {
        for (T item : items) {
            ksession.insert(item);
            // ksession.fireAllRules();
        }
        return items;
    }

    private void init() {
        /* KieServices kieServices = KieServices.Factory.get();       
         kContainer = kieServices.getKieClasspathContainer();     
         KieBase kBase = kContainer.getKieBase("SenslyticsStreamModeRulesEngineKB");
         ksession = kContainer.newKieSession("CountEvents");
         PropertiesConfiguration prop = new PropertiesUtils().getProperties("inference.properties");
         Set<String> set = prepareSet(prop);
         ksession.setGlobal("set",set ); 
         ksession.setGlobal("counter", prop.getInt("counterThreshold"));
         ksession.setGlobal("timewindow", prop.getString("timeWindowThreshold")); */
        System.setProperty("drools.dialect.java.strict", "false");
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        /* kbuilder.add(ResourceFactory.newClassPathResource("CountHelloWorld.drl",TagEventDrools.class), ResourceType.DRL ); */
        Map<String, TagEvent> map = RulesEngineDAO.selectAllConfigDetails();
        for (TagEvent tagEvent : map.values()) {
            kbuilder.add(ResourceFactory.newReaderResource(TagEventRuleBuilder.buildRuleFromTemplate(tagEvent)), ResourceType.DRL);
        }
        Collection<KnowledgePackage> pkgs = kbuilder.getKnowledgePackages();
        KieBaseConfiguration kbaseConfiguration = KnowledgeBaseFactory.newKnowledgeBaseConfiguration();
        kbaseConfiguration.setOption(EventProcessingOption.STREAM);
        final KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase(kbaseConfiguration);
        // final RuleBase ruleBase = RuleBaseFactory.newRuleBase(// RuleBase.RETEOO, conf );
        kbase.addKnowledgePackages(pkgs);
        KieSessionConfiguration sessionConf = KnowledgeBaseFactory.newKnowledgeSessionConfiguration();
        sessionConf.setOption(ClockTypeOption.get("realtime"));
        ksession = kbase.newStatefulKnowledgeSession(sessionConf, null);
        Map<String, TagEvent> globalMap = RulesEngineDAO.selectAllConfigDetails();
        ksession.setGlobal("map", globalMap);
        new Thread() {
            @Override
            public void run() {
                ksession.fireUntilHalt();
            }
        }.start();

    }

    public void destroy() {
        ksession.dispose();
    }

}
