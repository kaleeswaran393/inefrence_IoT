package com.senselytics.inference.vo;

import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;


public class TagEventTimeTracker {
	private ConcurrentHashMap<String, ArrayBlockingQueue<TagEvent>> tagEvents = new ConcurrentHashMap<String, ArrayBlockingQueue<TagEvent>>();

	private static int limit = 100; //Configurable
	public void addEvent(String tagName, int tagValue, Date tagTime) {
		TagEvent tag = new TagEvent();
		tag.setTagName(tagName);
		tag.setTagTime(tagTime);
		tag.setTagValue(tagValue);
		ArrayBlockingQueue<TagEvent> aList = tagEvents.get(tagName);
		if (null == aList) {
			aList = new ArrayBlockingQueue<TagEvent>(limit);
			tagEvents.put(tagName, aList);			
		}
		aList.add(tag);
                    if(aList.size() > limit){
			aList.poll();
		}
	}
}
