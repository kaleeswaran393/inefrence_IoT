/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package papers;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.configuration.PropertiesConfiguration;

import oracle.kv.KVStore;
import oracle.kv.table.FieldRange;
import oracle.kv.table.MultiRowOptions;
import oracle.kv.table.PrimaryKey;
import oracle.kv.table.Row;
import oracle.kv.table.Table;
import oracle.kv.table.TableAPI;
import com.senslytics.datadendron.utils.PropertiesUtils;

/**
 *
 * @author Noah
 */
public class DataAccess {
	static Logger log=Logger.getLogger(DataAccess.class.getName());

    public static void main(String[] args) {
        ArrayList alDataNOSQL=new ArrayList();
            try
            {
            	PropertiesConfiguration prop=  new PropertiesUtils().getProperties();
//                String[] sTagName={"GSA_YE11152","GSA_VE11156Y","GSA_TT11101","GSA_LT11153","GSA_SI11151"};
               
                String[] sTagName={
                	//	"GSA_YE11152",
                	//	"GSA_VE11156Y",
                //		"GSA_TT11101",
               // 		"GSA_SI11151",
               // 		"GSA_ProdWell_P1_Current", 
               // "GSA_ProdWell_P1_DischargePressure", 
               // "GSA_ProdWell_P1_IntakePressure",
              // "GSA_ProdWell_P1_MotorTemp",
                "GSA_ProdWell_P1_Voltage"
                		};
                for(int x=0,y=sTagName.length;x<y;x++)
                {
                	Integer isDataFailure=1;//1 for failure, 0 for success
    	       		String sTemp="";
    	       		String str="";
    	       		if(isDataFailure==1)
    	       		{
    	       	ORAConnectionFactory ocf=new ORAConnectionFactory();
    	       	KVStore store = ocf.getKVStore();
    	       	List<Row> myRows = null;
    	       	TableAPI tableAPI = ocf.getTableAPI(store);
    	       	Table tableChild = tableAPI.getTable("pi_sensor.tag_detail");
    	       	PrimaryKey key=tableChild.createPrimaryKey();
    	       	key.put("tag_name",sTagName[x]);

    	       	FieldRange fh = tableChild.createFieldRange("tag_time");
    	       	fh.setStart(prop.getString(sTagName[x]+"_start"), true);
    	       	fh.setEnd(prop.getString(sTagName[x]+"_end"), true);
    	       	MultiRowOptions mro = fh.createMultiRowOptions();

    	       	myRows = tableAPI.multiGet(key, mro, null);
    	       	int i=0;
    	       	
    	       	System.out.println("Size of Current Selection"+myRows.size());
    	       	int iRowSize=myRows.size();
    	       	for(int p=0,q=iRowSize;p<q;p++)
    	       	{
    	       	   Row theRow=myRows.get(p);
    	       	    if(i<myRows.size() && !theRow.get("tag_value").asString().get().equalsIgnoreCase("null"))
    	       	   { 
//    	       	    System.out.println(theRow.get("tag_name").asString().get()+" "+theRow.get("tag_value").asString().get()+" "+theRow.get("tag_time").asString().get());
    	       	    if(i==(myRows.size()-1))
    	       	    {
    	       	        sTemp=sTemp+theRow.get("tag_value").asString().get();
    	       	    }
    	       	    else
    	       	    {
    	       	        sTemp=sTemp+theRow.get("tag_value").asString().get()+",";
    	       	    }
    	       	    i++;
    	       	   }
    	       	}
    	       	sTemp=sTemp+",1";
    	       	 System.out.println("Last Row"+sTemp);
    	       	    str = "@relation Train-Experiment-2\n"+
    	       	            
    	       	            "@attribute V2 numeric\n"+
    	       	            "@attribute V3 numeric\n"+
    	       	            "@attribute V4 numeric\n"+
    	       	            "@attribute V5 numeric\n"+
    	       	            "@attribute V6 numeric\n"+
    	       	            "@attribute V7 numeric\n"+
    	       	            "@attribute V8 numeric\n"+
    	       	            "@attribute V9 numeric\n"+
    	       	            "@attribute V10 numeric\n"+
    	       	            "@attribute V11 numeric\n"+
    	       	            "@attribute V12 numeric\n"+
    	       	            "@attribute V13 numeric\n"+
    	       	            "@attribute V14 numeric\n"+
    	       	            "@attribute V15 numeric\n"+
    	       	            "@attribute V16 numeric\n"+
    	       	            "@attribute V17 numeric\n"+
    	       	            "@attribute V18 numeric\n"+
    	       	            "@attribute V19 numeric\n"+
    	       	            "@attribute V20 numeric\n"+
    	       	            "@attribute V21 numeric\n"+            
    	       	            "@attribute V22 numeric\n"+
    	       	            "@attribute V23 numeric\n"+
    	       	            "@attribute V24 numeric\n"+
    	       	            "@attribute V25 numeric\n"+
    	       	            "@attribute V26 numeric\n"+
    	       	            "@attribute V27 numeric\n"+
    	       	            "@attribute V28 numeric\n"+
    	       	            "@attribute V29 numeric\n"+
    	       	            "@attribute V30 numeric\n";
    	       	 if(iRowSize==30)   {      str=str+  "@attribute V31 numeric\n";}
    	       	 if(iRowSize==31)   {  
    	       		 str=str+  "@attribute V31 numeric\n";
    	       		 str=str+  "@attribute V32 numeric\n";}           
    	       	 str=str+      "@attribute V1 {1,0}\n"+
    	       	            "@data\n"+
    	       	            sTemp+"\n";
    	       	 
    	       	}
    	       		else
    	       		{
    	       			ORAConnectionFactory ocf=new ORAConnectionFactory();
    	       			KVStore store = ocf.getKVStore();
    	       			List<Row> myRows = null;
    	       			TableAPI tableAPI = ocf.getTableAPI(store);
    	       			Table tableChild = tableAPI.getTable("pi_sensor.tag_detail");
    	       			PrimaryKey key=tableChild.createPrimaryKey();
    	       			key.put("tag_name",sTagName[x]);


    	       			myRows = tableAPI.multiGet(key, null, null);
    	       			int i=0;
    	       			System.out.println("Size of Current Selection"+myRows.size());
    	       			int iRowSize=30;
    	       			String sStartTime="";
    	       			String sEndTime="";
    	       			 for(int p=myRows.size()-iRowSize,q=myRows.size();p<q;p++)
    	       			{
    	       			   Row theRow=myRows.get(p);
    	       			    if(i<iRowSize && !theRow.get("tag_value").asString().get().equalsIgnoreCase("null"))
    	       			   { 
    	       			  //  System.out.println(theRow.get("tag_name").asString().get()+" "+theRow.get("tag_value").asString().get()+" "+theRow.get("tag_time").asString().get());
    	       			    if(i==iRowSize-1)
    	       			    {
    	       			        sTemp=sTemp+theRow.get("tag_value").asString().get();
    	       			    }
    	       			    else
    	       			    {
    	       			        sTemp=sTemp+theRow.get("tag_value").asString().get()+",";
    	       			    }
    	       			    
    	       			   }
    	       			   if(i==0) 
    	       			   {
    	       				   sStartTime=theRow.get("tag_time").asString().get();
    	       			   }
    	       			   if(i==iRowSize-1)
    	       			    {
    	       				   sEndTime=theRow.get("tag_time").asString().get();
    	       			    }
    	       			   i++;
    	       			} 

    	       			sTemp=sTemp+",1";
    	       				    str = "@relation Train-Experiment-2\n"+
    	       			            
    	       			            "@attribute V2 numeric\n"+
    	       			            "@attribute V3 numeric\n"+
    	       			            "@attribute V4 numeric\n"+
    	       			            "@attribute V5 numeric\n"+
    	       			            "@attribute V6 numeric\n"+
    	       			            "@attribute V7 numeric\n"+
    	       			            "@attribute V8 numeric\n"+
    	       			            "@attribute V9 numeric\n"+
    	       			            "@attribute V10 numeric\n"+
    	       			            "@attribute V11 numeric\n"+
    	       			            "@attribute V12 numeric\n"+
    	       			            "@attribute V13 numeric\n"+
    	       			            "@attribute V14 numeric\n"+
    	       			            "@attribute V15 numeric\n"+
    	       			            "@attribute V16 numeric\n"+
    	       			            "@attribute V17 numeric\n"+
    	       			            "@attribute V18 numeric\n"+
    	       			            "@attribute V19 numeric\n"+
    	       			            "@attribute V20 numeric\n"+
    	       			            "@attribute V21 numeric\n"+            
    	       			            "@attribute V22 numeric\n"+
    	       			            "@attribute V23 numeric\n"+
    	       			            "@attribute V24 numeric\n"+
    	       			            "@attribute V25 numeric\n"+
    	       			            "@attribute V26 numeric\n"+
    	       			            "@attribute V27 numeric\n"+
    	       			            "@attribute V28 numeric\n"+
    	       			            "@attribute V29 numeric\n"+
    	       			            "@attribute V30 numeric\n";
    	       			 if(iRowSize==30)   {      str=str+  "@attribute V31 numeric\n";}
    	       			 if(iRowSize==31)   {  
    	       				 str=str+  "@attribute V31 numeric\n";
    	       				 str=str+  "@attribute V32 numeric\n";}           
    	       			 str=str+      "@attribute V1 {1,0}\n"+
    	       			            "@data\n"+
    	       			            sTemp+"\n";
    	       			    
    	       		}
    	       		String sForInstance=str;
                    double dCurrPred=papers.DMKD_2013_Updated.getPrediction(sTagName[x],isDataFailure,sForInstance);
                    System.out.println("Prediction for tag "+sTagName[x]+"is "+dCurrPred);
                }
            }
            catch(Exception e)
            {
                System.out.println("Exception at Data Access"+e.getMessage());
            }
    }
}

