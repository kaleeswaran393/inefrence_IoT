/*-
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package papers;

import java.util.logging.Logger;
import oracle.kv.KVStore;
import oracle.kv.KVStoreConfig;
import oracle.kv.KVStoreFactory;
import oracle.kv.table.TableAPI;

/**
 *
 * @author Noah
 */
public class ORAConnectionFactory {
    	static Logger log=Logger.getLogger(ORAConnectionFactory.class.getName());

	public KVStore getKVStore()
	{
		log.info("In ORAConnectionFactory getKVStore()");
		KVStore store=null;
		try
		{	
	        store = KVStoreFactory.getStore
	                (new KVStoreConfig("kvstore","20.0.0.7" + ":" + "5000"));
	    }
		catch(Exception e)
		{
			log.info("ORAConnectionFactory unable creating store"+e.getMessage());
		}
		return store;
	}
	
	public TableAPI getTableAPI(KVStore kvstore)
	{
		log.info("In ORAConnectionFactory getTableAPI()");
		TableAPI table=null;
		try
		{
			table=kvstore.getTableAPI();
		}
		catch(Exception e)
		{
			log.info("ORAConnectionFactory unable creating TableAPI"+e.getMessage());
		}
		return table;
	}
}
